// Own containers, database, namespace and uploads. Never runs against an external database.
import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { mkdtemp, writeFile, rm, readFile, utimes } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import net from 'node:net';
import mongoose from 'mongoose';
import Redis from 'ioredis';
import jwt from 'jsonwebtoken';
import { request, connect, emit, event, until, sleep } from './test-support.js';
const runId = 'cki_test_' + Date.now().toString(36) + '_' + randomBytes(3).toString('hex');
const root = fileURLToPath(new URL('../../', import.meta.url));
const sockets = [], children = [], owned = [], cases = [];
let redis, directory, infrastructure, clientSocketModule;
const docker = args => execFileSync('docker', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
const freePort = () => new Promise(resolve => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); });
async function container(role, image, port, command = []) {
  const name = runId + '_' + role;
  const hostPort = await freePort();
  owned.push(name); docker(['run', '-d', '--name', name, '-p', '127.0.0.1:' + hostPort + ':' + port, image, ...command]);
  const address = docker(['port', name, String(port)]).split(':').at(-1); return Number(address);
}
async function check(name, body) {
  const start = Date.now(); await body(); const entry = { name, status: 'passed', durationMs: Date.now() - start }; cases.push(entry); console.log('PASS ' + name);
}
try {
  directory = await mkdtemp(join(tmpdir(), 'cki-integration-'));
  const mongoPort = await container('mongo', 'mongo:7.0', 27017);
  const redisPort = await container('redis', 'redis:7-alpine', 6379);
  Object.assign(process.env, {
    MONGO_URI: `mongodb://127.0.0.1:${mongoPort}/${runId}`, REDIS_URL: `redis://127.0.0.1:${redisPort}`,
    REDIS_PREFIX: runId + ':', UPLOAD_DIR: directory, JWT_ACCESS_SECRET: randomBytes(48).toString('hex'), JWT_REFRESH_SECRET: randomBytes(48).toString('hex'),
    PRESENCE_TTL_MS: '1500', PRESENCE_HEARTBEAT_MS: '400', PRESENCE_SWEEP_MS: '200', CACHE_TTL_SECONDS: '2', RATE_MESSAGE: '1000', RATE_TYPING: '6', TRUST_PROXY_HOPS: '0',
  });
  await until(async () => { try { await mongoose.connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 500 }); return true; } catch { return false; } }, 60000);
  redis = new Redis(process.env.REDIS_URL, { retryStrategy: () => 200 }); redis.on('error', () => {}); await until(() => redis.status === 'ready');
  const ports = [await freePort(), await freePort()];
  const urls = ports.map(p => 'http://127.0.0.1:' + p);
  async function start(index) {
    const child = spawn(process.execPath, ['src/index.js'], { cwd: join(root, 'server'), env: { ...process.env, PORT: String(ports[index]), INSTANCE_ID: 'integration-' + index }, stdio: ['ignore', 'pipe', 'pipe'] });
    children[index] = child;
    let output = ''; child.stdout.on('data', b => { output = (output + b).slice(-30000); }); child.stderr.on('data', b => { output = (output + b).slice(-30000); });
    child.output = () => output;
    await until(async () => {
      if (child.exitCode !== null) throw new Error(output);
      return (await fetch(urls[index] + '/ready')).ok;
    }, 30000).catch(error => { throw new Error(error.message + ' ' + output); });
  }
  await start(0); await start(1);
  const { User } = await import('../src/models/User.js');
  const { Message } = await import('../src/models/Message.js');
  const { Conversation } = await import('../src/models/Conversation.js');
  const { Upload } = await import('../src/models/Upload.js');
  const { cleanupUploads } = await import('./cleanup-uploads.js');
  infrastructure = await import('../src/config/redis.js'); await infrastructure.connectRedis();
  const accounts = [];
  const req = (i, path, options) => request(urls[i], '/api' + path, options);
  for (const role of ['alice', 'bob', 'outsider']) accounts.push(await req(0, '/auth/register', { method: 'POST', status: 201, body: { username: role + '_' + runId.slice(-10), email: role + '_' + runId + '@example.test', password: randomBytes(20).toString('hex') } }));
  const [a, b, c] = accounts;
  const invite = await req(0, '/friends/request', { method: 'POST', token: a.accessToken, status: 201, body: { recipientId: b.user._id } });
  const { conversationId } = await req(1, '/friends/request/' + invite._id + '/accept', { method: 'PUT', token: b.accessToken });
  let sa, sb, secondA;
  await check('two real processes, cross-instance message / typing / seen / history', async () => {
    sa = await connect(urls[0], a.accessToken, sockets); sb = await connect(urls[1], b.accessToken, sockets);
    assert.notEqual(sa.instance, sb.instance); assert.notEqual(children[0].pid, children[1].pid);
    const received = event(sb, 'message:received');
    const ack = await emit(sa, 'message:send', { conversationId, text: 'cross instance', clientMessageId: 'cross-instance-01' });
    assert.equal(ack.success, true); assert.equal((await received)._id, ack.message._id);
    const typing = event(sb, 'typing:status'); assert.equal((await emit(sa, 'typing:start', { conversationId })).success, true); assert.equal((await typing).isTyping, true);
    const seen = event(sa, 'message:seen_ack'); assert.equal((await emit(sb, 'message:seen', { conversationId, lastReadMessageId: ack.message._id })).success, true); await seen;
    assert.equal((await req(0, '/messages/' + conversationId, { token: a.accessToken }))[0].status, 'seen');
    await req(1, '/messages/' + conversationId, { token: c.accessToken, status: 403 });
  });
  await check('concurrent retry across A/B, conflict, seen and preview do not regress', async () => {
    const payload = { conversationId, text: 'same', clientMessageId: 'simultaneous-retry-01' };
    const [one, two] = await Promise.all([req(0, '/messages/send', { method: 'POST', status: 201, token: a.accessToken, body: payload }), req(1, '/messages/send', { method: 'POST', status: 201, token: a.accessToken, body: payload })]);
    assert.equal(one._id, two._id); assert.equal(await Message.countDocuments({ clientMessageId: payload.clientMessageId }), 1);
    await req(1, '/messages/' + conversationId + '/seen', { method: 'PUT', token: b.accessToken, body: { lastReadMessageId: one._id } });
    await req(0, '/messages/send', { method: 'POST', token: a.accessToken, status: 409, body: { ...payload, text: 'conflict' } });
    const latest = await req(1, '/messages/send', { method: 'POST', status: 201, token: a.accessToken, body: { ...payload, text: 'latest', clientMessageId: 'latest-message-01' } });
    const retry = await req(0, '/messages/send', { method: 'POST', status: 201, token: a.accessToken, body: payload });
    assert.equal(retry.status, 'seen'); assert.equal(String((await Conversation.findById(conversationId)).lastMessage.messageId), latest._id);
  });
  await check('presence multiple sockets, last close, crash TTL and reconnect', async () => {
    secondA = await connect(urls[1], a.accessToken, sockets);
    const online = async () => (await req(1, '/friends/all', { token: b.accessToken }))[0].user.isOnline;
    await until(online); sa.disconnect(); await sleep(250); assert.equal(await online(), true);
    secondA.disconnect(); await until(async () => !(await online()));
    sa = await connect(urls[0], a.accessToken, sockets); await until(online);
    children[0].kill('SIGKILL'); await until(async () => !(await online()), 6000);
    await start(0); sa = await connect(urls[0], a.accessToken, sockets); await until(online);
  });
  await check('cache miss/hit/TTL, profile and friend invalidation across instances', async () => {
    const metrics = async i => (await req(i, '/diagnostics', { token: a.accessToken })).cache;
    const { cached, invalidate, cacheStats } = await import('../src/services/cache.service.js');
    let release, started;
    const gate = new Promise(resolve => { release = resolve; });
    const loading = new Promise(resolve => { started = resolve; });
    const old = cached('concurrent-race', async () => { started(); await gate; return 'old'; });
    await loading; await invalidate('concurrent-race');
    await cached('concurrent-race', async () => 'new'); release(); assert.equal(await old, 'old');
    assert.equal(await cached('concurrent-race', async () => 'wrong'), 'new'); assert.ok(cacheStats().rejectedFill >= 1);
    const before = await metrics(1); await req(1, '/auth/me', { token: a.accessToken }); await req(1, '/auth/me', { token: a.accessToken });
    assert.ok((await metrics(1)).hit > before.hit);
    await req(0, '/auth/profile', { method: 'PUT', token: a.accessToken, body: { bio: 'updated profile' } });
    assert.equal((await req(1, '/auth/me', { token: a.accessToken })).bio, 'updated profile');
    const m = await metrics(1); await sleep(2100); await req(1, '/auth/me', { token: a.accessToken }); assert.ok((await metrics(1)).miss > m.miss);
    await req(0, '/friends/all', { token: a.accessToken }); await req(1, '/friends/' + b.user._id, { method: 'DELETE', token: a.accessToken });
    assert.equal((await req(0, '/friends/all', { token: a.accessToken })).length, 0);
    assert.equal((await req(1, '/friends/all', { token: b.accessToken })).length, 0);
    const invite2 = await req(0, '/friends/request', { method: 'POST', token: a.accessToken, status: 201, body: { recipientId: b.user._id } });
    await req(1, '/friends/request/' + invite2._id + '/accept', { method: 'PUT', token: b.accessToken });
    assert.equal((await req(0, '/friends/all', { token: a.accessToken })).length, 1);
  });
  await check('authorized file A→B, forged metadata, outsider, signatures, legacy and cleanup', async () => {
    const form = () => { const f = new FormData(); f.append('file', new Blob(['hello attachment'], { type: 'text/plain' }), 'hello.txt'); return f; };
    await req(0, '/upload/' + conversationId, { method: 'POST', token: c.accessToken, body: form(), status: 403 });
    const attachment = await req(0, '/upload/' + conversationId, { method: 'POST', token: a.accessToken, body: form(), status: 201 });
    const download = (account, status = 200) => request(urls[1], attachment.url, { token: account.accessToken, status, raw: true });
    assert.equal(await (await download(a)).text(), 'hello attachment'); await download(b, 403); await download(c, 403);
    await req(0, '/messages/send', { method: 'POST', token: a.accessToken, status: 400, body: { conversationId, clientMessageId: 'file-forged-001', attachments: [{ ...attachment, fileName: 'forged.txt' }] } });
    // A rejected metadata claim remains safe; use a fresh upload for the valid send.
    const valid = await req(0, '/upload/' + conversationId, { method: 'POST', token: a.accessToken, body: form(), status: 201 });
    await req(0, '/messages/send', { method: 'POST', token: a.accessToken, status: 201, body: { conversationId, clientMessageId: 'file-valid-0001', attachments: [valid] } });
    assert.equal(await (await request(urls[1], valid.url, { token: b.accessToken, raw: true })).text(), 'hello attachment');
    await request(urls[1], valid.url, { status: 401, raw: true });
    const oversized = new FormData(); oversized.append('file', new Blob([Buffer.alloc(20 * 1024 * 1024 + 1)], { type: 'text/plain' }), 'large.txt');
    await req(1, '/upload/' + conversationId, { method: 'POST', token: a.accessToken, body: oversized, status: 400 });
    const bad = new FormData(); bad.append('file', new Blob(['not a png'], { type: 'image/png' }), 'fake.png');
    await req(0, '/upload/' + conversationId, { method: 'POST', token: a.accessToken, body: bad, status: 400 });
    const legacy = randomBytes(16).toString('hex'); const name = legacy.slice(0,8)+'-'+legacy.slice(8,12)+'-'+legacy.slice(12,16)+'-'+legacy.slice(16,20)+'-'+legacy.slice(20)+'.txt';
    await writeFile(join(directory, name), 'legacy');
    await Message.create({ conversationId, sender: a.user._id, recipient: b.user._id, attachments: [{ url: '/uploads/' + name, fileName: 'legacy.txt', fileType: 'text/plain' }] });
    assert.equal(await (await request(urls[1], '/uploads/' + name, { token: b.accessToken, raw: true })).text(), 'legacy');
    await request(urls[1], '/uploads/' + name, { token: c.accessToken, status: 403, raw: true });
    await Upload.updateMany({}, { $set: { updatedAt: new Date(Date.now() - 48 * 3600000) } }, { timestamps: false });
    const orphan = 'u-00000000-0000-0000-0000-000000000001.txt';
    await writeFile(join(directory, orphan), 'aborted before metadata');
    const past = new Date(Date.now() - 48 * 3600000); await utimes(join(directory, orphan), past, past);
    const dry = await cleanupUploads(); assert.ok(dry.candidates >= 1); assert.equal(dry.deleted, 0);
    const result = await cleanupUploads({ apply: true }); assert.ok(result.deleted >= 1); assert.ok(result.retained >= 1);
    assert.equal(await (await request(urls[1], valid.url, { token: b.accessToken, raw: true })).text(), 'hello attachment');
    assert.equal(await readFile(join(directory, name), 'utf8'), 'legacy');
  });
  await check('history with >150 new messages and deterministic cursors', async () => {
    for (let n = 0; n < 161; n++) await req(n % 2, '/messages/send', { method: 'POST', status: 201, token: a.accessToken, body: { conversationId, clientMessageId: 'catch-up-message-' + String(n).padStart(4, '0'), text: 'page-' + n } });
    const ids = new Set(); let before;
    do {
      const response = await fetch(urls[1] + '/api/messages/' + conversationId + '?limit=50' + (before ? '&before=' + before : ''), { headers: { Authorization: 'Bearer ' + b.accessToken } });
      const page = await response.json(); assert.equal(response.status, 200);
      for (const row of page.data) { assert.ok(!ids.has(row._id)); ids.add(row._id); } before = page.pagination.nextCursor;
    } while (before);
    assert.equal(ids.size, await Message.countDocuments({ conversationId }));
  });
  await check('distributed typing limits are shared by A/B', async () => {
    await redis.del(process.env.REDIS_PREFIX + 'rate:typing:' + a.user._id);
    const duplicateA = await connect(urls[1], a.accessToken, sockets);
    for (let n = 0; n < 6; n++) assert.equal((await emit(n % 2 ? duplicateA : sa, 'typing:stop', { conversationId })).success, true);
    const denied = await emit(duplicateA, 'typing:start', { conversationId }); assert.equal(denied.status, 429);
    duplicateA.disconnect();
  });
  await check('Redis outage readiness fail-closed, then Pub/Sub subscriptions recover', async () => {
    docker(['stop', owned.find(n => n.endsWith('_redis'))]);
    await until(async () => (await fetch(urls[0] + '/ready')).status === 503);
    await req(1, '/auth/me', { token: a.accessToken, status: 503 });
    // Exercise the actual client retry path against a rejected 503 handshake, not a mock.
    globalThis.window = new EventTarget(); window.location = { origin: urls[0] };
    const storage = new Map([['accessToken', a.accessToken], ['refreshToken', a.refreshToken]]);
    globalThis.localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value), removeItem: key => storage.delete(key) };
    clientSocketModule = await import('../../client/src/services/socket.js');
    const retryingClient = clientSocketModule.initSocket(a.accessToken);
    assert.equal((await event(retryingClient, 'connect_error')).data.status, 503);
    docker(['start', owned.find(n => n.endsWith('_redis'))]);
    await until(async () => (await fetch(urls[0] + '/ready')).ok && (await fetch(urls[1] + '/ready')).ok, 20000);
    await until(() => retryingClient.connected, 10000);
    clientSocketModule.disconnectSocket();
    await sleep(300);
    const received = event(sb, 'message:received', m => m.clientMessageId === 'after-redis-recovery');
    const ack = await emit(sa, 'message:send', { conversationId, text: 'redis recovered', clientMessageId: 'after-redis-recovery' });
    assert.equal(ack.success, true); await received;
  });
  await check('expiry/refresh and logout revoke sockets/tokens on both backends', async () => {
    const claims = { userId: a.user._id, tokenVersion: 0, kind: 'access' };
    const expired = jwt.sign(claims, process.env.JWT_ACCESS_SECRET, { expiresIn: -1 });
    await req(0, '/auth/me', { token: expired, status: 401 });
    const short = await connect(urls[0], jwt.sign(claims, process.env.JWT_ACCESS_SECRET, { expiresIn: 2 }), sockets);
    await event(short, 'auth:expired'); await until(() => !short.connected);
    const refreshed = await req(1, '/auth/refresh-token', { method: 'POST', body: { refreshToken: a.refreshToken } }); assert.ok(refreshed.accessToken);
    secondA = await connect(urls[1], a.accessToken, sockets);
    await req(0, '/auth/logout', { method: 'POST', token: a.accessToken });
    await until(() => !sa.connected && !secondA.connected);
    await req(1, '/auth/me', { token: a.accessToken, status: 401 });
    await req(1, '/auth/refresh-token', { method: 'POST', body: { refreshToken: a.refreshToken }, status: 401 });
    assert.equal((await User.findById(a.user._id)).tokenVersion, 1);
  });
  await check('shared auth and upload rate limits across processes', async () => {
    await redis.del(process.env.REDIS_PREFIX + 'rate:auth:127.0.0.1');
    for (let n = 0; n < 30; n++) await req(n % 2, '/auth/login', { method: 'POST', body: { identifier: 'not-a-real-user', password: 'invalid' }, status: 401 });
    await req(1, '/auth/login', { method: 'POST', body: { identifier: 'not-a-real-user', password: 'invalid' }, status: 429 });
    await redis.del(process.env.REDIS_PREFIX + 'rate:upload:' + c.user._id);
    for (let n = 0; n < 20; n++) await req(n % 2, '/upload/' + conversationId, { method: 'POST', token: c.accessToken, status: 403 });
    await req(1, '/upload/' + conversationId, { method: 'POST', token: c.accessToken, status: 429 });
  });
} catch (error) {
  cases.push({ name: 'failure', status: 'failed', message: error.message }); console.error(error.stack); process.exitCode = 1;
  for (const child of children) if (child) console.error(child.output?.());
} finally {
  clientSocketModule?.disconnectSocket();
  sockets.forEach(socket => socket.disconnect());
  for (const child of children) if (child && child.exitCode === null) child.kill('SIGTERM');
  await sleep(500);
  for (const child of children) if (child && child.exitCode === null) child.kill('SIGKILL');
  if (mongoose.connection.readyState === 1 && mongoose.connection.name === runId) await mongoose.connection.dropDatabase();
  await infrastructure?.closeRedis();
  await mongoose.disconnect(); redis?.disconnect();
  for (const name of owned.reverse()) { try { docker(['rm', '-f', '-v', name]); } catch { /* Owned disposable container only. */ } }
  if (directory) await rm(directory, { recursive: true, force: true });
  await writeFile(join(root, 'reports/integration.json'), JSON.stringify({ runId, date: new Date().toISOString(), node: process.version, timings: { leaseMs: 1500, heartbeatMs: 400, sweepMs: 200 }, cases }, null, 2));
}
