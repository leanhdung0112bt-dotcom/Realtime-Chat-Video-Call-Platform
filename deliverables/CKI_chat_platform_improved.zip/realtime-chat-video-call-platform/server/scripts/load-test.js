// Reproducible authenticated workload in isolated disposable containers + real backend processes.
import { spawn, execFileSync } from 'node:child_process';
import { mkdtemp, rm, readFile, writeFile, mkdir } from 'node:fs/promises';
import { tmpdir, cpus, totalmem } from 'node:os';
import { join } from 'node:path';
import net from 'node:net';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import mongoose from 'mongoose';
import Redis from 'ioredis';
import bcrypt from 'bcryptjs';
import { connect, emit, until, sleep, request } from './test-support.js';
const num = (name, fallback, min, max) => {
  const n = Number(process.env[name] || fallback);
  if (!Number.isFinite(n) || n < min || n > max) throw new Error('Invalid ' + name);
  return n;
};
const config = {
  clients: num('CLIENTS', 20, 2, 1000), backends: num('BACKENDS', 2, 1, 2),
  senderRatio: num('SENDER_RATIO', 0.2, 0.01, 1), ratePerSender: num('RATE', 1, 0.01, 20),
  payloadBytes: num('PAYLOAD_BYTES', 128, 1, 4000), warmupSeconds: num('WARMUP', 2, 0, 120),
  durationSeconds: num('DURATION', 8, 1, 600), timeoutMs: num('ACK_TIMEOUT_MS', 8000, 500, 30000), seed: num('SEED', 42, 1, 2147483647),
};
if (!Number.isInteger(config.clients) || config.clients % 2 || !Number.isInteger(config.backends)) throw new Error('CLIENTS must be even and BACKENDS an integer');
const root = fileURLToPath(new URL('../../', import.meta.url));
const runId = 'cki_load_' + Date.now().toString(36) + '_' + randomBytes(3).toString('hex');
const containers = [], children = [], sockets = [], samples = [];
const records = new Map(), ackLatencies = [], peerLatencies = [];
let database, redis, uploads, sampling, redisBefore, mongoBefore;
let sendCount = 0, ackSuccess = 0, ackError = 0, duplicateRealtime = 0, reconnects = 0, connections = 0;
let schedulingLagMs = 0, rssPeak = process.memoryUsage().rss;
const errors = {};
const docker = args => execFileSync('docker', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
const freePort = () => new Promise(resolve => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); });
async function container(role, image, port) {
  const name = runId + '_' + role; containers.push(name);
  const hostPort = await freePort();
  docker(['run', '-d', '--name', name, '-p', '127.0.0.1:' + hostPort + ':' + port, image]);
  return Number(docker(['port', name, String(port)]).split(':').at(-1));
}
const percentiles = values => {
  const a = [...values].sort((x, y) => x - y);
  const at = p => a.length ? a[Math.min(a.length - 1, Math.ceil(a.length * p) - 1)] : null;
  return { count: a.length, p50: at(0.5), p95: at(0.95), max: a.at(-1) ?? null };
};
async function processStats(pid) {
  try {
    const fields = (await readFile('/proc/' + pid + '/stat', 'utf8')).split(' ');
    const status = await readFile('/proc/' + pid + '/status', 'utf8');
    return { pid, cpuTicks: Number(fields[13]) + Number(fields[14]), rssBytes: Number(status.match(/VmRSS:\s+(\d+)/)?.[1] || 0) * 1024 };
  } catch { return { pid, unavailable: true }; }
}
async function mongoStats() {
  const s = await mongoose.connection.db.admin().serverStatus();
  return { residentMB: s.mem?.resident, cpu: s.extra_info, connections: s.connections?.current };
}
let outcome, failure;
try {
  uploads = await mkdtemp(join(tmpdir(), 'cki-load-'));
  const mp = await container('mongo', 'mongo:7.0', 27017), rp = await container('redis', 'redis:7-alpine', 6379);
  Object.assign(process.env, { MONGO_URI: `mongodb://127.0.0.1:${mp}/${runId}`, REDIS_URL: `redis://127.0.0.1:${rp}`, REDIS_PREFIX: runId + ':', UPLOAD_DIR: uploads,
    JWT_ACCESS_SECRET: randomBytes(48).toString('hex'), JWT_REFRESH_SECRET: randomBytes(48).toString('hex') });
  await until(async () => { try { await mongoose.connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 500 }); return true; } catch { return false; } }, 60000);
  database = mongoose.connection.name;
  redis = new Redis(process.env.REDIS_URL); redis.on('error', () => {}); await until(() => redis.status === 'ready');
  const { User } = await import('../src/models/User.js');
  const { Friendship } = await import('../src/models/Friendship.js');
  const { Conversation } = await import('../src/models/Conversation.js');
  const { Message } = await import('../src/models/Message.js');
  const { generateTokens } = await import('../src/utils/token.utils.js');
  await Promise.all([User.init(), Friendship.init(), Conversation.init(), Message.init()]);
  // Seed only this run's DB. Authentication and membership checks remain enabled in the server.
  const password = await bcrypt.hash(randomBytes(24).toString('hex'), 10);
  const users = await User.insertMany(Array.from({ length: config.clients }, (_, i) => ({ username: 'load_' + i, email: 'load_' + i + '@example.test', password })));
  const pairs = [];
  for (let i = 0; i < users.length; i += 2) {
    const ids = [String(users[i]._id), String(users[i + 1]._id)];
    await Friendship.create({ requester: ids[0], recipient: ids[1], pairKey: ids.slice().sort().join(':'), status: 'accepted' });
    const c = await Conversation.create({ participants: ids, directKey: ids.slice().sort().join(':'), type: 'direct' });
    pairs.push(String(c._id));
  }
  const urls = [];
  for (let i = 0; i < config.backends; i++) {
    const port = await freePort(), url = 'http://127.0.0.1:' + port; urls.push(url);
    const child = spawn(process.execPath, ['src/index.js'], { cwd: join(root, 'server'), env: { ...process.env, PORT: String(port), INSTANCE_ID: 'load-' + i }, stdio: 'ignore' });
    children.push(child); await until(async () => (await fetch(url + '/ready')).ok, 30000);
  }
  const tokens = users.map(user => generateTokens({ userId: String(user._id), username: user.username, email: user.email, tokenVersion: 0 }).accessToken);
  // Stagger connection bursts, retaining real authentication and presence work.
  for (let start = 0; start < users.length; start += 25) {
    await Promise.all(users.slice(start, start + 25).map(async (_user, offset) => {
      const i = start + offset;
      const socket = await connect(urls[i % urls.length], tokens[i], sockets); connections++;
      socket.on('connect', () => reconnects++);
      socket.on('message:received', message => {
        const record = records.get(message.clientMessageId);
        if (!record || String(message.sender?._id || message.sender) === String(users[i]._id)) return;
        record.deliveries++; if (record.deliveries > 1) duplicateRealtime++;
        if (record.deliveries === 1 && record.measured) peerLatencies.push(performance.now() - record.start);
      });
      users[i].socket = socket;
    }));
  }
  const instances = sockets.reduce((m, s) => { m[s.instance] = (m[s.instance] || 0) + 1; return m; }, {});
  const senderCount = Math.max(1, Math.floor(config.clients * config.senderRatio));
  let seed = config.seed, sequence = 0;
  const rng = () => { seed = seed * 16807 % 2147483647; return seed / 2147483647; };
  async function send(sender, measured) {
    const id = runId + '-' + sequence++, conversationId = pairs[Math.floor(sender / 2)];
    const record = { start: performance.now(), conversationId, sender, deliveries: 0, measured, ack: false }; records.set(id, record);
    if (measured) sendCount++;
    try {
      const ack = await new Promise((resolve, reject) => users[sender].socket.timeout(config.timeoutMs).emit('message:send', { conversationId, text: 'x'.repeat(config.payloadBytes), clientMessageId: id }, (error, value) => error ? reject(error) : resolve(value)));
      if (!ack.success) throw new Error(ack.code || 'ACK_ERROR');
      record.ack = true; record.messageId = ack.message._id;
      if (measured) { ackSuccess++; ackLatencies.push(performance.now() - record.start); }
    } catch (error) { if (measured) { ackError++; errors[error.message] = (errors[error.message] || 0) + 1; } }
  }
  async function phase(seconds, measured) {
    const start = performance.now(), end = start + seconds * 1000;
    const next = Array.from({ length: senderCount }, () => start + rng() * 1000 / config.ratePerSender);
    const pending = new Set();
    while (performance.now() < end) {
      const now = performance.now();
      for (let i = 0; i < senderCount; i++) if (next[i] <= now) {
        schedulingLagMs = Math.max(schedulingLagMs, now - next[i]); next[i] += 1000 / config.ratePerSender;
        const job = send(i, measured); pending.add(job); void job.finally(() => pending.delete(job));
      }
      await sleep(5);
    }
    await Promise.all(pending); return (performance.now() - start) / 1000;
  }
  await phase(config.warmupSeconds, false);
  redisBefore = await redis.info('cpu'); mongoBefore = await mongoStats();
  const generatorBefore = process.cpuUsage(); const procBefore = await Promise.all(children.map(c => processStats(c.pid)));
  sampling = setInterval(() => {
    rssPeak = Math.max(rssPeak, process.memoryUsage().rss);
    void Promise.all(children.map(c => processStats(c.pid))).then(values => samples.push({ elapsedMs: performance.now(), backends: values }));
  }, 1000);
  const elapsedSeconds = await phase(config.durationSeconds, true); await sleep(500);
  clearInterval(sampling);
  const realtimeMissing = [...records.values()].filter(r => r.measured && !r.deliveries).length;
  const generatorCpu = process.cpuUsage(generatorBefore), procAfter = await Promise.all(children.map(c => processStats(c.pid)));
  const redisAfter = await redis.info('cpu'), redisMemory = await redis.info('memory'), mongoAfter = await mongoStats();
  const cpu = info => Object.fromEntries(info.split(/\r?\n/).filter(l => l.includes(':')).map(l => { const [k, v] = l.split(':'); return [k, Number(v)]; }));
  const rb = cpu(redisBefore), ra = cpu(redisAfter), rm = cpu(redisMemory);
  // Measure catch-up separately and reconcile by ID against durable storage.
  const catchupStart = performance.now(); let missingAfterCatchup = 0, dbMissing = 0, dbDuplicates = 0;
  for (let pair = 0; pair < pairs.length; pair++) {
    const recovered = new Set(); let before;
    do {
      const response = await fetch(urls[(pair * 2 + 1) % urls.length] + '/api/messages/' + pairs[pair] + '?limit=100' + (before ? '&before=' + before : ''), { headers: { Authorization: 'Bearer ' + tokens[pair * 2 + 1] } });
      if (!response.ok) throw new Error('Catch-up HTTP ' + response.status);
      const page = await response.json(); page.data.forEach(m => recovered.add(m.clientMessageId)); before = page.pagination.nextCursor;
    } while (before);
    const relevant = [...records].filter(([, r]) => r.measured && r.conversationId === pairs[pair]);
    const db = await Message.find({ conversationId: pairs[pair], clientMessageId: { $in: relevant.map(([id]) => id) } }).select('clientMessageId').lean();
    const counts = new Map(); db.forEach(m => counts.set(m.clientMessageId, (counts.get(m.clientMessageId) || 0) + 1));
    for (const [id, r] of relevant) {
      if (!recovered.has(id)) missingAfterCatchup++;
      if (r.ack && !counts.has(id)) dbMissing++;
      if ((counts.get(id) || 0) > 1) dbDuplicates++;
    }
  }
  outcome = { elapsedSeconds, connections, instanceDistribution: instances, sent: sendCount, offeredMessagesPerSecond: sendCount / elapsedSeconds,
    ackSuccess, ackError, errors, ackMessagesPerSecond: ackSuccess / elapsedSeconds, ackLatencyMs: percentiles(ackLatencies), peerLatencyMs: percentiles(peerLatencies),
    realtime: { missing: realtimeMissing, duplicateEvents: duplicateRealtime },
    catchup: { durationMs: performance.now() - catchupStart, missing: missingAfterCatchup, dbMissingAcknowledged: dbMissing, dbDuplicates }, reconnects,
    resources: { generator: { cpuUserMs: generatorCpu.user / 1000, cpuSystemMs: generatorCpu.system / 1000, rssPeakBytes: rssPeak, schedulingLagMaxMs: schedulingLagMs },
      backends: { before: procBefore, after: procAfter, samples, clockTicksPerSecond: Number(execFileSync('getconf', ['CLK_TCK'], { encoding: 'utf8' })) },
      redis: { cpuSeconds: ra.used_cpu_user + ra.used_cpu_sys - rb.used_cpu_user - rb.used_cpu_sys, usedMemoryBytes: rm.used_memory, peakMemoryBytes: rm.used_memory_peak }, mongodb: { before: mongoBefore, after: mongoAfter } },
  };
  if (ackError || missingAfterCatchup || dbMissing || dbDuplicates) process.exitCode = 1;
} catch (error) { failure = error.message; console.error(error.stack); process.exitCode = 1; }
finally {
  clearInterval(sampling); sockets.forEach(s => s.disconnect());
  for (const child of children) child.kill('SIGTERM'); await sleep(500); for (const child of children) if (child.exitCode === null) child.kill('SIGKILL');
  if (mongoose.connection.readyState === 1 && database === runId) await mongoose.connection.dropDatabase();
  await mongoose.disconnect(); redis?.disconnect();
  for (const name of containers.reverse()) { try { docker(['rm', '-f', '-v', name]); } catch { /* Own resources only. */ } }
  if (uploads) await rm(uploads, { recursive: true, force: true });
  let commit = null; try { commit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8', stdio: 'pipe' }).trim(); } catch { /* ZIP has no Git metadata. */ }
  const report = { runId, date: new Date().toISOString(), commit, config, environment: { node: process.version, cpuCount: cpus().length, cpuModel: cpus()[0]?.model, totalMemoryBytes: totalmem(), budget: 'Host processes share the same machine; no enforced per-backend CPU/memory limit. DB/Redis in Docker. Generator on the same machine.' }, result: outcome, failure };
  await mkdir(join(root, 'reports'), { recursive: true });
  await writeFile(join(root, 'reports', runId + '.json'), JSON.stringify(report, null, 2));
  if (outcome) await writeFile(join(root, 'reports', runId + '.csv'), 'runId,backends,clients,sent,ackSuccess,ackError,p50Ms,p95Ms,peerP95Ms,realtimeMissing,catchupMissing\n' + [runId, config.backends, config.clients, outcome.sent, outcome.ackSuccess, outcome.ackError, outcome.ackLatencyMs.p50, outcome.ackLatencyMs.p95, outcome.peerLatencyMs.p95, outcome.realtime.missing, outcome.catchup.missing].join(',') + '\n');
  console.log(JSON.stringify({ runId, config, result: outcome && { ...outcome, resources: '(see JSON report)' }, failure }, null, 2));
}
