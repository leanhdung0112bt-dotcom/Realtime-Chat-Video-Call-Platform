import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
const requireClient = createRequire(new URL('../../client/package.json', import.meta.url));
export const { io } = requireClient('socket.io-client');
export const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
export async function until(check, ms = 10000) {
  const end = Date.now() + ms; let error;
  while (Date.now() < end) {
    try { const result = await check(); if (result) return result; } catch (e) { error = e; }
    await sleep(100);
  }
  throw new Error('Condition timed out' + (error ? ': ' + error.message : ''));
}
export async function request(base, path, { method = 'GET', token, body, status = 200, raw = false } = {}) {
  const form = body instanceof FormData;
  const res = await fetch(base + path, { method, headers: { ...(token ? { Authorization: 'Bearer ' + token } : {}), ...(body && !form ? { 'Content-Type': 'application/json' } : {}) }, body: body ? form ? body : JSON.stringify(body) : undefined, signal: AbortSignal.timeout(10000) });
  if (raw) { assert.equal(res.status, status, path); return res; }
  const data = await res.json();
  assert.equal(res.status, status, method + ' ' + path + ': ' + (data.message || 'unexpected status'));
  return data.data ?? data;
}
export async function connect(base, token, list = []) {
  const socket = io(base, { autoConnect: false, transports: ['websocket'], auth: { token }, reconnection: false, timeout: 5000 });
  list.push(socket);
  const info = event(socket, 'server:info');
  await new Promise((resolve, reject) => { socket.once('connect', resolve); socket.once('connect_error', reject); socket.connect(); });
  socket.instance = (await info).instanceId;
  return socket;
}
export const emit = (socket, name, payload) => new Promise((resolve, reject) => socket.timeout(8000).emit(name, payload, (e, ack) => e ? reject(e) : resolve(ack)));
export function event(socket, name, predicate = () => true, ms = 10000) {
  return new Promise((resolve, reject) => {
    const listener = value => { if (!predicate(value)) return; clearTimeout(timer); socket.off(name, listener); resolve(value); };
    const timer = setTimeout(() => { socket.off(name, listener); reject(new Error('Missing ' + name)); }, ms);
    socket.on(name, listener);
  });
}
