import 'dotenv/config';
import mongoose from 'mongoose';
import { Message } from '../src/models/Message.js';
import { Conversation } from '../src/models/Conversation.js';
import { Friendship } from '../src/models/Friendship.js';
// Audit only; never delete documents or synchronize/drop existing indexes.
try {
  await mongoose.connect(process.env.MONGO_URI, { autoIndex: false });
  for (const [model, key, match] of [
    [Message, { conversationId: '$conversationId', sender: '$sender', clientMessageId: '$clientMessageId' }, { clientMessageId: { $type: 'string' } }],
    [Conversation, { directKey: '$directKey' }, { directKey: { $type: 'string' } }],
    [Friendship, { pairKey: '$pairKey' }, { pairKey: { $type: 'string' } }],
  ]) {
    const duplicates = await model.aggregate([{ $match: match }, { $group: { _id: key, count: { $sum: 1 }, ids: { $push: '$_id' } } }, { $match: { count: { $gt: 1 } } }, { $limit: 20 }]);
    console.log(JSON.stringify({ model: model.modelName, duplicates, indexes: await model.collection.indexes() }));
    if (duplicates.length) process.exitCode = 1;
  }
} finally { await mongoose.disconnect(); }
