import { unlink } from 'node:fs/promises';
import { Upload } from '../models/Upload.js';
import { Message } from '../models/Message.js';
import { AppError } from '../utils/errors.js';
import { requireConversation } from '../services/access.service.js';
import { attachmentView, readableFile } from '../services/upload.service.js';
import { verifyContent } from '../middlewares/upload.middleware.js';
import { managedName, storedPath } from '../config/storage.js';
export async function authorizeUpload(req, _res, next) {
  try { req.conversation = await requireConversation(String(req.user._id), req.params.conversationId); next(); }
  catch (error) { next(error); }
}
export async function uploadSingle(req, res) {
  if (!req.file) throw new AppError(400, 'Chưa có file nào được tải lên.');
  try {
    await verifyContent(req.file);
    const file = await Upload.create({ uploader: req.user._id, conversationId: req.conversation._id,
      storedName: req.file.filename, originalName: req.file.originalname.replace(/[\x00-\x1f\x7f/\\]/g, '_').slice(0, 255) || 'file',
      mime: req.file.mimetype, size: req.file.size });
    res.status(201).json({ success: true, data: attachmentView(file) });
  } catch (error) { await unlink(req.file.path).catch(() => {}); throw error; }
}
function sendFile(res, file) {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; sandbox", 'Cache-Control': 'private, no-store' });
  res.type(file.mime || 'application/octet-stream');
  res.attachment(file.originalName);
  res.sendFile(storedPath(file.storedName));
}
export async function downloadFile(req, res) { sendFile(res, await readableFile(String(req.user._id), req.params.fileId)); }
export async function downloadLegacy(req, res) {
  const name = req.params.name;
  if (!managedName(name)) throw new AppError(404, 'Không tìm thấy file.');
  const file = await Upload.findOne({ storedName: name });
  if (file) { sendFile(res, await readableFile(String(req.user._id), String(file._id))); return; }
  const messages = Message.find({ 'attachments.url': '/uploads/' + name }).cursor();
  for await (const message of messages) {
    try { await requireConversation(String(req.user._id), String(message.conversationId)); }
    catch (error) { if ([400, 403, 404].includes(error.status)) continue; throw error; }
    const attachment = message.attachments.find(a => a.url === '/uploads/' + name);
    // Legacy MIME is untrusted. Download as an attachment, never execute in origin.
    sendFile(res, { storedName: name, originalName: attachment.fileName || name, mime: 'application/octet-stream' });
    return;
  }
  throw new AppError(403, 'File cũ chưa có tham chiếu hội thoại hợp lệ.');
}
