import { instanceId } from './utils/logger.js';
import { rateLimit } from './services/rate-limit.service.js';
import { cacheStats } from './services/cache.service.js';
import { redisReady, scalingEnabled, stopping } from './config/redis.js';
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import { errorHandler } from "./utils/errors.js";
import {
  register,
  login,
  refreshToken,
  getMe,
  updateProfile,
  logout,
} from "./controllers/auth.controller.js";
import {
  searchUsers,
  sendFriendRequest,
  acceptFriendRequest,
  declineFriendRequest,
  getFriends,
  getFriendRequests,
  removeFriend,
} from "./controllers/friend.controller.js";
import {
  getConversations,
  getOrCreateConversation,
  getMessages,
  sendMessage,
  markAsSeen,
} from "./controllers/message.controller.js";
import { uploadSingle, authorizeUpload, downloadFile, downloadLegacy } from "./controllers/upload.controller.js";
import { authenticate } from "./middlewares/auth.middleware.js";
import { validate } from "./middlewares/validate.middleware.js";
import { upload } from "./middlewares/upload.middleware.js";
import {
  registerSchema,
  loginSchema,
  refreshTokenSchema,
  updateProfileSchema,
} from "./validations/auth.validation.js";

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', Number(process.env.TRUST_PROXY_HOPS || 0));
app.use((_req, res, next) => { res.set('X-Instance-Id', instanceId); next(); });

// Global Middlewares
app.use(
  cors({
    origin: (process.env.CORS_ORIGIN || 'http://localhost:3000').split(','),
  })
);
app.use(express.json({ limit: '256kb' }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', instanceId, timestamp: new Date().toISOString() });
});

app.get('/ready', (_req, res) => {
  const ready = !stopping && mongoose.connection.readyState === 1 && redisReady();
  res.status(ready ? 200 : 503).json({ status: ready ? 'ready' : 'not_ready', instanceId, mongo: mongoose.connection.readyState === 1, redis: redisReady() });
});

app.use('/api', (_req, res, next) => {
  if (stopping || (scalingEnabled() && !redisReady())) return res.status(503).json({ success: false, message: 'Hạ tầng đang phục hồi. Hãy thử lại.' });
  next();
});
app.get('/api/diagnostics', authenticate, (_req, res) => res.json({ success: true, data: { instanceId, cache: cacheStats() } }));
// --- Auth Routes ---
const authRouter = express.Router();
authRouter.post('/register', rateLimit('auth'), validate(registerSchema), register);
authRouter.post('/login', rateLimit('auth'), validate(loginSchema), login);
authRouter.post('/refresh-token', rateLimit('auth'), validate(refreshTokenSchema), refreshToken);
authRouter.get('/me', authenticate, getMe);
authRouter.put('/profile', authenticate, validate(updateProfileSchema), updateProfile);
authRouter.post('/logout', authenticate, logout);
app.use('/api/auth', authRouter);

// --- Friend & Contacts Routes ---
const friendRouter = express.Router();
friendRouter.get('/search', authenticate, searchUsers);
friendRouter.get('/all', authenticate, getFriends);
friendRouter.get('/requests', authenticate, getFriendRequests);
friendRouter.post('/request', authenticate, sendFriendRequest);
friendRouter.put('/request/:requestId/accept', authenticate, acceptFriendRequest);
friendRouter.delete('/request/:requestId/decline', authenticate, declineFriendRequest);
friendRouter.delete('/:friendId', authenticate, removeFriend);
app.use('/api/friends', friendRouter);

// --- Messages & Conversation Routes ---
const messageRouter = express.Router();
messageRouter.get('/conversations', authenticate, getConversations);
messageRouter.get('/conversation/:friendId', authenticate, getOrCreateConversation);
messageRouter.get('/:conversationId', authenticate, getMessages);
messageRouter.post('/send', authenticate, sendMessage);
messageRouter.put('/:conversationId/seen', authenticate, markAsSeen);
app.use('/api/messages', messageRouter);

// --- Upload Routes ---
const uploadRouter = express.Router();
uploadRouter.post('/:conversationId', authenticate, rateLimit('upload'), authorizeUpload, upload.single('file'), uploadSingle);
uploadRouter.post('/', authenticate, (_req, res) => res.status(400).json({ success: false, message: 'Dùng POST /api/upload/:conversationId.' }));
app.use('/api/upload', uploadRouter);
app.get('/api/files/:fileId', authenticate, downloadFile);
app.get('/uploads/:name', authenticate, downloadLegacy);

// 404 handler
app.use((_req, res) => {
  res.status(404).json({ success: false, message: 'Resource not found' });
});

app.use(errorHandler);

export default app;
