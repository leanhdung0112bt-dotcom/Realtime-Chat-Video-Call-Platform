import { command, prefix, scalingEnabled } from '../config/redis.js';
import { AppError } from '../utils/errors.js';
export const limits = {
  auth: [Number(process.env.RATE_AUTH || 30), 60000],
  upload: [Number(process.env.RATE_UPLOAD || 20), 60000],
  message: [Number(process.env.RATE_MESSAGE || 120), 60000],
  typing: [Number(process.env.RATE_TYPING || 120), 60000],
  event: [Number(process.env.RATE_EVENT || 600), 60000],
};
for (const [kind, [limit]] of Object.entries(limits)) {
  if (!Number.isInteger(limit) || limit < 1) throw new Error('Invalid rate limit: ' + kind);
}
export async function consume(kind, identity) {
  if (!scalingEnabled()) return; // Unit-only app without runtime; production always connects Redis first.
  if (command?.status !== 'ready') throw new AppError(503, 'Redis chưa sẵn sàng, hãy thử lại.');
  const [limit, window] = limits[kind];
  const key = prefix + 'rate:' + kind + ':' + identity;
  const count = await command.eval(`local n = redis.call('INCR', KEYS[1]); if n == 1 then redis.call('PEXPIRE', KEYS[1], ARGV[1]) end; return n`, 1, key, window);
  if (count > limit) throw new AppError(429, 'Quá nhiều yêu cầu. Hãy chờ rồi thử lại.');
}
export const rateLimit = kind => async (req, _res, next) => {
  try { await consume(kind, req.user ? String(req.user._id) : req.ip); next(); }
  catch (error) { next(error); }
};
