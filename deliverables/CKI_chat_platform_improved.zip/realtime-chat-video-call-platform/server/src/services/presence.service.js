import { command, prefix } from '../config/redis.js';
import { User } from '../models/User.js';
import { Friendship } from '../models/Friendship.js';
import { emitToUsers } from '../sockets/events.js';
import { log } from '../utils/logger.js';
export const leaseMs = Number(process.env.PRESENCE_TTL_MS || 45000);
export const heartbeatMs = Number(process.env.PRESENCE_HEARTBEAT_MS || 10000);
export const sweepMs = Number(process.env.PRESENCE_SWEEP_MS || 5000);
if (![leaseMs, heartbeatMs, sweepMs].every(Number.isInteger) || leaseMs < heartbeatMs * 3 || heartbeatMs < 200 || sweepMs < 100) throw new Error('Invalid presence timing');
const due = prefix + 'presence:due';
const script = `
local now = tonumber(ARGV[1]); local ttl = tonumber(ARGV[2]); local mode = ARGV[3]
redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', now)
if mode == 'touch' then redis.call('ZADD', KEYS[1], now + ttl, ARGV[4]) end
if mode == 'remove' then redis.call('ZREM', KEYS[1], ARGV[4]) end
local online = redis.call('ZCARD', KEYS[1]) > 0 and '1' or '0'
local old = redis.call('HGET', KEYS[2], 'online') or '0'
local changed = old ~= online
if changed then
 redis.call('HSET', KEYS[2], 'online', online, 'changedAt', now)
 redis.call('HINCRBY', KEYS[2], 'version', 1)
 if online == '0' then redis.call('HSET', KEYS[2], 'lastSeen', now) end
end
if online == '1' then
 local first = redis.call('ZRANGE', KEYS[1], 0, 0, 'WITHSCORES')
 redis.call('ZADD', KEYS[3], first[2], ARGV[5])
 redis.call('PEXPIRE', KEYS[1], ttl * 2)
else redis.call('ZREM', KEYS[3], ARGV[5]); redis.call('DEL', KEYS[1]) end
return {online, redis.call('HGET', KEYS[2], 'lastSeen') or '', changed and '1' or '0', redis.call('HGET', KEYS[2], 'version') or '0'}
`;
async function update(id, mode, socketId = '') {
  if (command?.status !== 'ready') return { isOnline: false, presenceAvailable: false };
  const [online, last, changed, version] = await command.eval(script, 3,
    prefix + 'presence:sockets:' + id, prefix + 'presence:state:' + id, due,
    Date.now(), leaseMs, mode, socketId, id);
  const state = { userId: id, isOnline: online === '1', lastSeen: last ? new Date(Number(last)).toISOString() : null, presenceVersion: Number(version), presenceAvailable: true };
  if (changed === '1') {
    // Only transitions write MongoDB; Redis remains authoritative for online.
    if (!state.isOnline) await User.updateOne({ _id: id, $or: [{ lastSeen: { $lt: new Date(last ? Number(last) : 0) } }, { lastSeen: { $exists: false } }] }, { $set: { lastSeen: state.lastSeen, isOnline: false } });
    const friends = await Friendship.find({ status: 'accepted', $or: [{ requester: id }, { recipient: id }] }).select('requester recipient').lean();
    emitToUsers(friends.map(f => String(f.requester) === id ? String(f.recipient) : String(f.requester)), 'user:presence', state);
  }
  return state;
}
export const touchPresence = (id, socketId) => update(id, 'touch', socketId);
export const removePresence = (id, socketId) => update(id, 'remove', socketId);
export async function presenceFor(id, fallback) {
  const state = await update(id, 'read');
  return { ...state, lastSeen: state.lastSeen || fallback || null };
}
export function startPresenceSweeper() {
  let running = false;
  const timer = setInterval(async () => {
    if (running || command?.status !== 'ready') return;
    running = true;
    try {
      const ids = await command.zrangebyscore(due, '-inf', Date.now(), 'LIMIT', 0, 200);
      await Promise.all(ids.map(id => update(id, 'read')));
    } catch { log('presence.sweep_failed'); }
    finally { running = false; }
  }, sweepMs);
  timer.unref();
  return () => clearInterval(timer);
}
