import { Conversation } from '../models/Conversation.js';
import { objectId, directRecipient } from '../utils/access.js';
import { AppError } from '../utils/errors.js';
// B must extend this single entry point for group membership, without trusting participants alone.
export async function requireConversation(userId, conversationId) {
  const conversation = await Conversation.findById(objectId(conversationId));
  if (!conversation) throw new AppError(404, 'Không tìm thấy cuộc trò chuyện.');
  directRecipient(conversation, userId);
  return conversation;
}
