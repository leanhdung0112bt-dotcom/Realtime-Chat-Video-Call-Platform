import { command, prefix } from '../config/redis.js';
import { log } from '../utils/logger.js';
const counters = { hit: 0, miss: 0, bypass: 0, invalidation: 0, rejectedFill: 0 };
const ttlSeconds = Number(process.env.CACHE_TTL_SECONDS || 60);
if (!Number.isInteger(ttlSeconds) || ttlSeconds < 1 || ttlSeconds > 86400) throw new Error('Invalid CACHE_TTL_SECONDS');
export const cacheStats = () => ({ ...counters });
// Epoch keys deliberately do not expire: avoid an ABA race with slow readers.
export async function cached(key, load) {
  const base = prefix + 'cache:' + key;
  if (command?.status !== 'ready') { counters.bypass++; return load(); }
  let epoch;
  try {
    const [version, value] = await command.mget(base + ':epoch', base + ':data');
    epoch = version || '0';
    if (value !== null) { counters.hit++; return JSON.parse(value); }
  } catch { counters.bypass++; return load(); }
  counters.miss++;
  const value = await load();
  try {
    const saved = await command.eval(`if (redis.call('GET', KEYS[1]) or '0') ~= ARGV[1] then return 0 end
      redis.call('SET', KEYS[2], ARGV[2], 'EX', ARGV[3]); return 1`, 2,
    base + ':epoch', base + ':data', epoch, JSON.stringify(value), ttlSeconds);
    if (!saved) counters.rejectedFill++;
  } catch { log('cache.fill_failed'); }
  return value;
}
export async function invalidate(...keys) {
  if (command?.status !== 'ready') return;
  for (const key of keys) {
    const base = prefix + 'cache:' + key;
    await command.multi().incr(base + ':epoch').del(base + ':data').exec();
    counters.invalidation++;
  }
}
