import { Upload } from '../models/Upload.js';
import { Message } from '../models/Message.js';
import { requireConversation } from './access.service.js';
import { objectId } from '../utils/access.js';
import { AppError } from '../utils/errors.js';
export const attachmentView = file => ({ fileId: String(file._id), url: '/api/files/' + file._id, fileType: file.mime, fileName: file.originalName, fileSize: file.size });
export async function resolveAttachments(userId, conversationId, attachments, clientMessageId) {
  const result = [];
  for (const input of attachments) {
    const id = objectId(input.fileId);
    const key = [conversationId, userId, clientMessageId].join(':');
    const file = await Upload.findOne({ _id: id, uploader: userId, conversationId, state: { $ne: 'deleting' } });
    if (!file) throw new AppError(403, 'File không thuộc bạn/hội thoại hoặc đã được dùng.');
    const canonical = attachmentView(file);
    for (const field of ['url', 'fileName', 'fileType', 'fileSize']) {
      if (input[field] !== undefined && input[field] !== canonical[field]) throw new AppError(400, 'Metadata file phải khớp dữ liệu server.');
    }
    const claimed = await Upload.findOneAndUpdate({ _id: id, state: { $ne: 'deleting' },
      $or: [{ messageKey: key }, { messageKey: { $exists: false } }] },
    { $set: { state: 'attached', messageKey: key } }, { returnDocument: 'after' });
    if (!claimed) throw new AppError(409, 'File đang được dọn hoặc đã thuộc một tin nhắn khác.');
    result.push(canonical);
  }
  return result;
}
export async function readableFile(userId, id) {
  const file = await Upload.findById(objectId(id));
  if (!file || file.state === 'deleting') throw new AppError(404, 'Không tìm thấy file.');
  await requireConversation(userId, String(file.conversationId));
  if (String(file.uploader) !== userId && !(await Message.exists({ conversationId: file.conversationId, 'attachments.fileId': file._id }))) throw new AppError(403, 'File chưa được chia sẻ.');
  return file;
}
