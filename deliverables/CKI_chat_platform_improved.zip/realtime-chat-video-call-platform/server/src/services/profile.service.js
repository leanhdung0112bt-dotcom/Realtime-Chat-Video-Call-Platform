import { User } from '../models/User.js';
import { Friendship } from '../models/Friendship.js';
import { cached, invalidate } from './cache.service.js';
import { presenceFor } from './presence.service.js';
export const publicFields = '_id username email avatar bio createdAt updatedAt';
export async function profile(id) {
  return cached('profile:' + id, () => User.findById(id).select(publicFields).lean());
}
export async function withPresence(user) {
  if (!user) return null;
  const value = user.toJSON ? user.toJSON() : { ...user };
  const p = await presenceFor(String(value._id), value.lastSeen);
  return { ...value, ...p };
}
export async function friendsFor(id) {
  const rows = await cached('friends:' + id, async () => {
    const relationships = await Friendship.find({ status: 'accepted', $or: [{ requester: id }, { recipient: id }] }).lean();
    return relationships.map(f => ({ friendshipId: String(f._id), userId: String(f.requester) === id ? String(f.recipient) : String(f.requester), since: f.updatedAt }));
  });
  const hydrated = await Promise.all(rows.map(async row => ({ friendshipId: row.friendshipId, since: row.since, user: await withPresence(await profile(row.userId)) })));
  return hydrated.filter(row => row.user);
}
export const invalidateFriends = (...ids) => invalidate(...ids.map(id => 'friends:' + id));
