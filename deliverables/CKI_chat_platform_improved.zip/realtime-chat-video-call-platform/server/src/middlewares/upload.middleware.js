import multer from 'multer';
import { randomUUID } from 'node:crypto';
import { open } from 'node:fs/promises';
import { AppError } from '../utils/errors.js';
import { uploadDir } from '../config/storage.js';
export const extensions = {
  'image/jpeg': '.jpg', 'image/png': '.png', 'image/gif': '.gif', 'image/webp': '.webp',
  'application/pdf': '.pdf', 'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'text/plain': '.txt', 'video/mp4': '.mp4', 'audio/mpeg': '.mp3', 'audio/wav': '.wav',
};
export const upload = multer({
  storage: multer.diskStorage({ destination: uploadDir, filename: (_req, file, cb) => cb(null, 'u-' + randomUUID() + extensions[file.mimetype]) }),
  limits: { fileSize: 20 * 1024 * 1024, files: 1, fields: 0, parts: 1 },
  fileFilter: (_req, file, cb) => extensions[file.mimetype] ? cb(null, true) : cb(new AppError(400, 'Loại file không được hỗ trợ.')),
});
export async function verifyContent(file) {
  const handle = await open(file.path, 'r');
  const bytes = Buffer.alloc(Math.min(file.size, 8192));
  try { await handle.read(bytes, 0, bytes.length, 0); } finally { await handle.close(); }
  const hex = bytes.toString('hex'), ascii = bytes.toString('latin1');
  const valid = {
    'image/jpeg': () => hex.startsWith('ffd8ff'),
    'image/png': () => hex.startsWith('89504e470d0a1a0a'),
    'image/gif': () => /^GIF8[79]a/.test(ascii),
    'image/webp': () => ascii.startsWith('RIFF') && ascii.slice(8, 12) === 'WEBP',
    'application/pdf': () => ascii.startsWith('%PDF-'),
    'application/msword': () => hex.startsWith('d0cf11e0a1b11ae1'),
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': () => hex.startsWith('504b0304'),
    'text/plain': () => !bytes.includes(0) && !bytes.some(b => b < 9 || (b > 13 && b < 32)),
    'video/mp4': () => ascii.slice(4, 8) === 'ftyp',
    'audio/mpeg': () => ascii.startsWith('ID3') || (bytes[0] === 255 && (bytes[1] & 224) === 224),
    'audio/wav': () => ascii.startsWith('RIFF') && ascii.slice(8, 12) === 'WAVE',
  }[file.mimetype];
  if (!file.size || !valid?.()) throw new AppError(400, 'Nội dung file không khớp loại đã khai báo.');
}
