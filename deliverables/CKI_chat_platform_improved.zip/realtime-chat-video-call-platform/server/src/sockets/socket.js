import { attachAdapter, redisReady } from '../config/redis.js';
import { touchPresence, removePresence, heartbeatMs } from '../services/presence.service.js';
import { consume } from '../services/rate-limit.service.js';
import { instanceId, log } from '../utils/logger.js';
import { Server } from 'socket.io';
import { verifyAccessToken } from "../utils/token.utils.js";
import { User } from "../models/User.js";
import { Friendship } from "../models/Friendship.js";
import { createMessage, markConversationSeen, requireConversation } from "../services/message.service.js";
import { directRecipient, objectId } from "../utils/access.js";
import { AppError } from "../utils/errors.js";
import { setIO, emitToUsers, getIO } from "./events.js";

export async function initSocket(httpServer) {
  const io = new Server(httpServer, {
    cors: { origin: (process.env.CORS_ORIGIN || 'http://localhost:3000').split(','), methods: ['GET', 'POST'] },
    transports: ['websocket'],
    pingTimeout: 20000, pingInterval: 25000, maxHttpBufferSize: 100000,
  });
  await attachAdapter(io);
  setIO(io);
  io.use(async (socket, next) => {
    try {
      if (!redisReady()) {
        const error = new Error('Hạ tầng đang phục hồi. Hãy thử lại.');
        error.data = { status: 503, code: 'DEPENDENCY_UNAVAILABLE' }; return next(error);
      }
      const token = socket.handshake.auth?.token;
      if (typeof token !== 'string') throw new Error();
      const claims = verifyAccessToken(token);
      const user = await User.findById(claims.userId);
      if (!user || (user.tokenVersion || 0) !== claims.tokenVersion) throw new Error();
      socket.data = { userId: String(user._id), username: user.username, tokenVersion: claims.tokenVersion, expiresAt: claims.exp * 1000 };
      next();
    } catch { next(new Error('Phiên đăng nhập hết hạn hoặc không hợp lệ.')); }
  });
  io.on('connection', socket => {
    const { userId, username, expiresAt } = socket.data;
    socket.join('user:' + userId);
    socket.emit('server:info', { instanceId, socketId: socket.id });
    log('socket.connected', { userId, socketId: socket.id });
    const expiryTimer = setTimeout(() => {
      socket.emit('auth:expired');
      socket.disconnect(true);
    }, Math.max(1, expiresAt - Date.now()));

    const validateSession = async () => {
      if (!redisReady()) throw new AppError(503, 'Redis chưa sẵn sàng. Hãy thử lại.');
      const current = await User.findById(userId).select('tokenVersion');
      if (!current || (current.tokenVersion || 0) !== socket.data.tokenVersion || Date.now() >= expiresAt) {
        socket.emit('auth:revoked'); socket.disconnect(true); throw new AppError(401, 'Phiên đăng nhập không còn hiệu lực.');
      }
    };
    let heartbeating = false;
    const beat = async () => {
      if (heartbeating || !socket.connected) return;
      heartbeating = true;
      try { await validateSession(); if (socket.connected) await touchPresence(userId, socket.id); }
      catch (error) { log('presence.heartbeat_failed', { socketId: socket.id, status: error.status || 503 }); }
      finally { heartbeating = false; }
    };
    const heartbeatTimer = setInterval(() => void beat(), heartbeatMs); heartbeatTimer.unref();
    void beat();
    const safe = (handler) => async (data, callback) => {
      try {
        await consume('event', userId);
        await validateSession();
        const result = await handler(data);
        if (typeof callback === 'function') callback({ success: true, ...(result  || {}) });
      } catch (error) {
        const message = error instanceof AppError ? error.message : 'Không thể xử lý yêu cầu.';
        if (typeof callback === 'function') callback({ success: false, error: message, status: error.status || 500, code: error.status === 429 ? 'RATE_LIMITED' : error.status === 503 ? 'DEPENDENCY_UNAVAILABLE' : 'REQUEST_FAILED' });
        else socket.emit('operation:error', { message });
      }
    };
    socket.on('conversation:join', safe(async id => {
      const conv = await requireConversation(userId, id);
      await socket.join('conversation:' + conv._id);
      return {};
    }));
    socket.on('conversation:leave', safe(async id => { await socket.leave('conversation:' + objectId(id)); return {}; }));
    socket.on('message:send', safe(async data => {
      const start = performance.now();
      const message = await createMessage(userId, data);
      log('message.saved', { socketId: socket.id, messageId: message?._id, conversationId: message?.conversationId, durationMs: performance.now() - start });
      return { message };
    }));
    socket.on('message:seen', safe(async data => markConversationSeen(userId, data?.conversationId, data?.lastReadMessageId)));
    for (const [event, isTyping] of [['typing:start', true], ['typing:stop', false]] ) {
      socket.on(event, safe(async data => {
        await consume('typing', userId);
        const conv = await requireConversation(userId, data?.conversationId);
        emitToUsers([directRecipient(conv, userId)], 'typing:status', { conversationId: String(conv._id), userId, username, isTyping });
        return {};
      }));
    }
    // Signaling scaffolding only. The browser media/call lifecycle is still a team task.
    const signalEvents = [
      ['call:initiate', 'call:incoming'], ['call:answer', 'call:answered'],
      ['call:ice-candidate', 'call:ice-candidate'], ['call:reject', 'call:rejected'], ['call:end', 'call:ended'],
    ];
    for (const [incoming, outgoing] of signalEvents) {
      socket.on(incoming, safe(async data => {
        const recipientId = objectId(data?.recipientId);
        const allowed = await Friendship.exists({ status: 'accepted', $or: [{ requester: userId, recipient: recipientId }, { requester: recipientId, recipient: userId }] });
        if (!allowed) throw new AppError(403, 'Chỉ có thể gọi cho bạn bè.');
        emitToUsers([recipientId], outgoing, { userId, callerId: userId, callerUsername: username, offer: data.offer, answer: data.answer, candidate: data.candidate, callType: data.callType === 'audio' ? 'audio' : 'video' });
        return {};
      }));
    }
    socket.on('disconnect', () => {
      clearTimeout(expiryTimer);
      clearInterval(heartbeatTimer);
      void removePresence(userId, socket.id).catch(() => log('presence.disconnect_failed'));
    });
  });
  return io;
}
export { getIO };

