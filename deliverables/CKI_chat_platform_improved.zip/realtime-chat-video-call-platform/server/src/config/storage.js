import path from 'node:path';
import { mkdirSync } from 'node:fs';
export const uploadDir = path.resolve(process.env.UPLOAD_DIR || path.join(process.cwd(), 'uploads'));
mkdirSync(uploadDir, { recursive: true });
export const managedName = name => /^(u-)?[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.(jpg|png|gif|webp|pdf|doc|docx|txt|mp4|mp3|wav)$/.test(name);
export function storedPath(name) {
  if (!managedName(name)) throw new Error('Invalid managed filename');
  return path.join(uploadDir, name);
}
