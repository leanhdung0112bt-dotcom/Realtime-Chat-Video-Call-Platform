import Redis from 'ioredis';
import { createAdapter } from '@socket.io/redis-adapter';
import { log } from '../utils/logger.js';

export const prefix = process.env.REDIS_PREFIX || 'chat:';
if (!/^[a-zA-Z0-9:_-]{1,100}$/.test(prefix)) throw new Error('Invalid REDIS_PREFIX');
export let command, pub, sub;
let enabled = false, adapterReady = false;
export let stopping = false;
const connectionsReady = () => [command, pub, sub].every(client => client?.status === 'ready');
export const redisReady = () => adapterReady && connectionsReady();
export const scalingEnabled = () => enabled;
export async function connectRedis() {
  enabled = true;
  const options = { lazyConnect: true, enableOfflineQueue: false, maxRetriesPerRequest: 1, commandTimeout: 3000,
    retryStrategy: n => Math.min(200 * n, 2000) };
  [command, pub, sub] = ['command', 'pub', 'sub'].map(role => {
    const client = new Redis(process.env.REDIS_URL || 'redis://127.0.0.1:6379', options);
    client.on('error', () => log('redis.error', { role }));
    client.on('ready', () => log('redis.ready', { role }));
    client.on('reconnecting', () => log('redis.reconnecting', { role }));
    return client;
  });
  await Promise.all([command.connect(), pub.connect(), sub.connect()]);
}
export async function attachAdapter(io) {
  let revision = 0;
  const unavailable = () => {
    revision++; adapterReady = false;
    if (!stopping) io.local.emit('server:degraded', { reason: 'redis' });
  };
  // The official adapter ignores these promises; keep rejection handling explicit.
  const publish = pub.publish.bind(pub);
  pub.publish = (...args) => publish(...args).catch(() => { log('redis.publish_failed'); unavailable(); return 0; });
  const subscriptions = { subscribe: new Set(), psubscribe: new Set() }, raw = {};
  for (const method of ['subscribe', 'psubscribe', 'unsubscribe', 'punsubscribe']) {
    raw[method] = sub[method].bind(sub);
    sub[method] = (...args) => {
      if (subscriptions[method]) for (const value of args.flat()) if (typeof value === 'string') subscriptions[method].add(value);
      return raw[method](...args).catch(() => { log('redis.subscription_failed', { method }); unavailable(); return 0; });
    };
  }
  io.adapter(createAdapter(pub, sub, { key: prefix + 'socket.io', requestsTimeout: 5000, publishOnSpecificResponseChannel: true }));
  const ready = async (notify = true) => {
    const expected = revision;
    if (stopping || !connectionsReady()) return;
    try {
      // Re-assert subscriptions and await their ACKs, including after auto-resubscribe.
      await raw.subscribe([...subscriptions.subscribe]);
      await raw.psubscribe([...subscriptions.psubscribe]);
      await sub.ping();
      if (revision !== expected || !connectionsReady()) return;
      adapterReady = true;
      if (notify && !stopping) io.local.emit('server:sync_required');
    } catch { unavailable(); }
  };
  for (const client of [command, pub, sub]) {
    client.on('close', unavailable);
    // ioredis queues auto-resubscriptions in its synchronous ready handler.
    client.on('ready', () => queueMicrotask(() => void ready()));
  }
  await ready(false);
  if (!redisReady()) throw new Error('Redis subscriptions not ready');
}
export function beginShutdown() { stopping = true; }
export async function closeRedis() {
  await Promise.allSettled([command, pub, sub].filter(Boolean).map(async client => {
    try { if (client.status === 'ready') await client.quit(); }
    finally { client.disconnect(); }
  }));
}
