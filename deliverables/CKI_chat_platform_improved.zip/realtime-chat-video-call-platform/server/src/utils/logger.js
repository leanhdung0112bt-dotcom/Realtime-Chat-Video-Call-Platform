export const instanceId = process.env.INSTANCE_ID || process.env.HOSTNAME || 'local';
export function log(event, fields = {}) {
  console.log(JSON.stringify({ time: new Date().toISOString(), instanceId, event, ...fields }));
}
