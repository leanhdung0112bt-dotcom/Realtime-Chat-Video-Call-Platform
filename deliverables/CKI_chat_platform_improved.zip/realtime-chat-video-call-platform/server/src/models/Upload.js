import mongoose, { Schema } from 'mongoose';
const schema = new Schema({
  uploader: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  conversationId: { type: Schema.Types.ObjectId, ref: 'Conversation', required: true, index: true },
  storedName: { type: String, required: true, unique: true },
  originalName: { type: String, required: true, maxlength: 255 },
  mime: { type: String, required: true }, size: { type: Number, required: true },
  state: { type: String, enum: ['ready', 'attached', 'deleting'], default: 'ready' },
  messageKey: String,
}, { timestamps: true });
schema.index({ state: 1, updatedAt: 1 });
// No TTL: cleanup must coordinate metadata, message references and the disk.
export const Upload = mongoose.model('Upload', schema);
