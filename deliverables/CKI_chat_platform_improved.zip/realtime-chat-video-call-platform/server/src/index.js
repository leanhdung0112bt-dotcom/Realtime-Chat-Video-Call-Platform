import 'dotenv/config';
import http from 'node:http';
import mongoose from 'mongoose';
import { validateTokenConfiguration } from './utils/token.utils.js';
import app from './app.js';
import { connectDB } from './config/db.js';
import { initSocket } from './sockets/socket.js';
import { connectRedis, closeRedis, beginShutdown } from './config/redis.js';
import { startPresenceSweeper } from './services/presence.service.js';
import { log } from './utils/logger.js';
let server, io, stopSweeper, closing = false;
async function shutdown(code = 0) {
  if (closing) return; closing = true; beginShutdown(); stopSweeper?.();
  log('server.stopping');
  const deadline = setTimeout(() => process.exit(1), 10000); deadline.unref();
  try {
    if (io) await new Promise(resolve => io.close(resolve));
    if (server?.listening) await new Promise(resolve => server.close(resolve));
    await mongoose.disconnect(); await closeRedis();
    clearTimeout(deadline); process.exitCode = code;
  } catch { process.exitCode = 1; }
}
try {
  validateTokenConfiguration();
  await connectDB();
  await Promise.all(Object.values(mongoose.models).map(model => model.init()));
  await connectRedis();
  server = http.createServer(app);
  io = await initSocket(server); stopSweeper = startPresenceSweeper();
  process.once('SIGTERM', () => void shutdown());
  process.once('SIGINT', () => void shutdown());
  server.listen(Number(process.env.PORT || 5000), '0.0.0.0', () => log('server.listening', { port: server.address().port }));
} catch (error) {
  log('server.start_failed', { name: error.name, code: error.code });
  await shutdown(1);
}
