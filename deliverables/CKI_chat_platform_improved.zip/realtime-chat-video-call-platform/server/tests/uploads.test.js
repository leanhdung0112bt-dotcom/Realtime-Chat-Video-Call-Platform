import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { verifyContent } from '../src/middlewares/upload.middleware.js';
import { normalizeMessage } from '../src/services/message.service.js';
import { managedName } from '../src/config/storage.js';

test('content validation rejects forged image and binary text, accepts actual signatures', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'cki-signature-'));
  try {
    for (const [name, mime, content, valid] of [
      ['forged.png', 'image/png', Buffer.from('<html>'), false],
      ['binary.txt', 'text/plain', Buffer.from([0, 1, 2]), false],
      ['empty.txt', 'text/plain', Buffer.alloc(0), false],
      ['ok.txt', 'text/plain', Buffer.from('Xin chào\n'), true],
      ['pdf.pdf', 'application/pdf', Buffer.from('%PDF-1.4\n'), true],
      ['png.png', 'image/png', Buffer.from('89504e470d0a1a0a', 'hex'), true],
    ]) {
      const path = join(dir, name); await writeFile(path, content);
      const job = verifyContent({ path, mimetype: mime, size: content.length });
      if (valid) await job; else await assert.rejects(job, e => e.status === 400);
    }
  } finally { await rm(dir, { recursive: true, force: true }); }
});
test('message attachments require server file IDs and reject duplicates or over five', () => {
  const fileId = 'aaaaaaaaaaaaaaaaaaaaaaaa';
  assert.equal(normalizeMessage({ attachments: [{ fileId }] }).attachments.length, 1);
  assert.throws(() => normalizeMessage({ attachments: [{ fileId }, { fileId }] }));
  assert.throws(() => normalizeMessage({ attachments: Array.from({ length: 6 }, () => ({ fileId })) }));
  assert.throws(() => normalizeMessage({ attachments: [{ url: '/uploads/forged.png' }] }));
});
test('managed names cannot escape storage; new orphan scope is distinct from legacy', () => {
  assert.ok(managedName('u-00000000-0000-0000-0000-000000000001.txt'));
  assert.ok(managedName('00000000-0000-0000-0000-000000000001.txt'));
  for (const name of ['../secret.txt', 'u-../../secret.txt', 'secret.txt', '/etc/passwd']) assert.ok(!managedName(name));
});
