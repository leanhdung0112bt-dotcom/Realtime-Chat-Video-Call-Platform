// Run against a disposable Compose stack. Does not bypass JWT or membership.
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
import { request, connect, emit, event, until } from '../server/scripts/test-support.js';
const base = process.env.BASE_URL || 'http://localhost:3000';
const sockets = [], checks = [];
const run = 'proxy_' + Date.now().toString(36);
const req = (path, options) => request(base, '/api' + path, options);
const docker = args => execFileSync('docker', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
try {
  await until(async () => (await fetch(base + '/ready')).ok, 30000);
  const accounts = [];
  for (const role of ['a', 'b', 'c']) accounts.push(await req('/auth/register', { method: 'POST', status: 201, body: { username: run + role, email: run + role + '@example.test', password: randomBytes(20).toString('hex') } }));
  const [a, b, outsider] = accounts;
  const invite = await req('/friends/request', { method: 'POST', status: 201, token: a.accessToken, body: { recipientId: b.user._id } });
  const { conversationId } = await req('/friends/request/' + invite._id + '/accept', { method: 'PUT', token: b.accessToken });
  for (let i = 0; i < 8; i++) await connect(base, (i % 2 ? b : a).accessToken, sockets);
  const distribution = sockets.reduce((m, s) => { m[s.instance] = (m[s.instance] || 0) + 1; return m; }, {});
  assert.equal(Object.keys(distribution).length, Number(process.env.EXPECT_BACKENDS || 2));
  checks.push({ name: 'websocket distribution via Nginx', distribution });
  const sender = sockets[0]; const receiver = sockets.find((s, i) => i % 2 === 1 && s.instance !== sender.instance) || sockets[1];
  const next = event(receiver, 'message:received', m => m.clientMessageId === run + '-message');
  assert.equal((await emit(sender, 'message:send', { conversationId, text: 'through nginx', clientMessageId: run + '-message' })).success, true); await next;
  const form = new FormData(); form.append('file', new Blob(['shared volume'], { type: 'text/plain' }), 'shared.txt');
  const file = await req('/upload/' + conversationId, { method: 'POST', token: a.accessToken, body: form, status: 201 });
  await req('/messages/send', { method: 'POST', token: a.accessToken, status: 201, body: { conversationId, clientMessageId: run + '-file', attachments: [file] } });
  const downloadedBy = new Set();
  for (let i = 0; i < 10; i++) {
    const response = await request(base, file.url, { token: b.accessToken, raw: true }); downloadedBy.add(response.headers.get('x-instance-id')); assert.equal(await response.text(), 'shared volume');
  }
  assert.equal(downloadedBy.size, Number(process.env.EXPECT_BACKENDS || 2));
  await request(base, file.url, { token: outsider.accessToken, status: 403, raw: true });
  checks.push({ name: 'cross-instance upload/download and permission', downloadedBy: [...downloadedBy] });
  if (process.env.TEST_RECREATE === '1') {
    const project = process.env.COMPOSE_PROJECT_NAME;
    if (!project?.startsWith('cki-')) throw new Error('Recreate only allowed for an explicitly named cki-* disposable project');
    const compose = ['compose', '-p', project];
    const cid = docker([...compose, 'ps', '-q', 'server-b']);
    const before = JSON.parse(docker(['inspect', cid]))[0];
    const network = Object.keys(before.NetworkSettings.Networks)[0], oldIP = before.NetworkSettings.Networks[network].IPAddress;
    docker([...compose, 'rm', '-f', '-s', 'server-b']);
    sockets.forEach(socket => socket.disconnect());
    // A temporary peer occupies an address so recreation can exercise changed DNS.
    const holder = project + '-dns-holder';
    try {
      docker(['run', '-d', '--name', holder, '--network', network, 'redis:7-alpine', 'sleep', '120']);
      await until(async () => (await fetch(base + '/ready')).ok);
      docker([...compose, 'up', '-d', '--no-deps', 'server-b']);
      await until(() => docker(['inspect', '--format', '{{.State.Health.Status}}', docker([...compose, 'ps', '-q', 'server-b'])]) === 'healthy', 30000);
      const newIP = JSON.parse(docker(['inspect', docker([...compose, 'ps', '-q', 'server-b'])]))[0].NetworkSettings.Networks[network].IPAddress;
      const instances = new Set();
      await until(async () => { const res = await fetch(base + '/health'); if (res.ok) instances.add(res.headers.get('x-instance-id')); return instances.size === 2; }, 30000);
      assert.equal(await (await request(base, file.url, { token: b.accessToken, raw: true })).text(), 'shared volume');
      checks.push({ name: 'backend recreate / DNS and retained shared volume', oldIP, newIP, addressActuallyChanged: oldIP !== newIP, instances: [...instances] });
    } finally { try { docker(['rm', '-f', holder]); } catch { /* Own holder only. */ } }
  }
  console.log(JSON.stringify({ status: 'passed', checks }, null, 2));
} catch (error) { console.error(error.stack); checks.push({ status: 'failed', message: error.message }); process.exitCode = 1; }
finally { sockets.forEach(s => s.disconnect()); await writeFile(new URL('../reports/proxy.json', import.meta.url), JSON.stringify({ date: new Date().toISOString(), checks }, null, 2)); }
