import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { request } from '../server/scripts/test-support.js';
const base = process.env.BASE_URL || 'http://localhost:3000';
const run = 'ui_' + Date.now().toString(36), password = randomBytes(20).toString('hex');
const checks = [], errors = [];
let browser;
const req = (path, options) => request(base, '/api' + path, options);
async function login(page, account) {
  await page.goto(base);
  await page.getByPlaceholder('name@example.com hoặc username').fill(account.user.username);
  await page.getByPlaceholder('••••••••').fill(password);
  await page.getByRole('button', { name: 'Đăng nhập ngay', exact: true }).click();
  await page.getByText('V-Chat', { exact: true }).waitFor();
}
async function visible(page, text) { await page.getByText(text, { exact: true }).first().waitFor(); }
try {
  const accounts = [];
  for (const role of ['a', 'b', 'c']) accounts.push(await req('/auth/register', { method: 'POST', status: 201, body: { username: run + role, email: run + role + '@example.test', password } }));
  const [a, b, c] = accounts;
  const invite = await req('/friends/request', { method: 'POST', status: 201, token: a.accessToken, body: { recipientId: b.user._id } });
  const { conversationId } = await req('/friends/request/' + invite._id + '/accept', { method: 'PUT', token: b.accessToken });
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined, headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage(); page.on('pageerror', e => errors.push(e.message));
  await login(page, a);
  await page.locator('aside button').filter({ hasText: b.user.username }).click();
  const input = page.getByPlaceholder('Nhắn tin cho @' + b.user.username + '...');
  await input.fill('browser-message'); await input.press('Enter'); await visible(page, 'browser-message');
  checks.push('desktop login / conversation / send');
  // A failed persisted-message request must leave the draft intact.
  await context.setOffline(true); await page.waitForTimeout(300);
  await input.fill('retry-draft'); await input.press('Enter'); await page.waitForTimeout(400);
  assert.equal(await input.inputValue(), 'retry-draft');
  await context.setOffline(false); await page.waitForTimeout(1000);
  await input.press('Enter'); await visible(page, 'retry-draft');
  checks.push('network failure keeps draft and retry succeeds');
  const image = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001a5f645400000000049454e44ae426082', 'hex');
  await page.locator('input[type=file]').setInputFiles({ name: 'preview.png', mimeType: 'image/png', buffer: image });
  await page.locator('img[alt="preview.png"]').waitFor();
  await page.waitForFunction(() => [...document.querySelectorAll('img[alt="preview.png"]')].some(img => img.naturalWidth > 0));
  await input.fill('with-image'); await input.press('Enter'); await visible(page, 'with-image');
  checks.push('authenticated image upload and Blob preview');
  await context.setOffline(true);
  for (let n = 0; n < 161; n++) await req('/messages/send', { method: 'POST', status: 201, token: (n % 2 ? a : b).accessToken,
    body: { conversationId, text: 'offline-history-' + String(n).padStart(3, '0'), clientMessageId: run + '-offline-' + n } });
  await context.setOffline(false);
  await page.locator('main').getByText('offline-history-160', { exact: true }).waitFor();
  await page.locator('main').getByText('offline-history-000', { exact: true }).waitFor();
  assert.equal(await page.locator('main').getByText(/^offline-history-/).count(), 161);
  checks.push('real UI reconnect catches up 161 persisted messages without duplicate rows');
  await input.fill('preserve-draft');
  const tab = await context.newPage(); await tab.goto(base); await visible(tab, 'V-Chat');
  await tab.locator('aside button').filter({ hasText: b.user.username }).click();
  await page.waitForTimeout(1100);
  const tokens = await req('/auth/refresh-token', { method: 'POST', body: { refreshToken: a.refreshToken } });
  await tab.evaluate(({ tokens, userId }) => {
    localStorage.setItem('accessToken', tokens.accessToken); localStorage.setItem('refreshToken', tokens.refreshToken);
    localStorage.setItem('chat:session', JSON.stringify({ ...tokens, userId }));
  }, { tokens, userId: a.user._id });
  await page.waitForTimeout(300); assert.equal(await input.inputValue(), 'preserve-draft');
  checks.push('same-account cross-tab refresh preserves draft');
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: '← Danh sách trò chuyện', exact: true }).click();
  await page.locator('aside button').filter({ hasText: b.user.username }).click();
  assert.equal(await input.inputValue(), 'preserve-draft');
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  checks.push('mobile navigation / draft restore / no horizontal overflow');
  // Simulate another tab committing a completed login. The receiving tab must clear old account state.
  await tab.evaluate(account => {
    localStorage.setItem('accessToken', account.accessToken); localStorage.setItem('refreshToken', account.refreshToken);
    localStorage.setItem('chat:session', JSON.stringify({ accessToken: account.accessToken, refreshToken: account.refreshToken, userId: account.user._id }));
  }, c);
  await page.getByText(c.user.username, { exact: true }).first().waitFor();
  assert.equal(await page.getByText('browser-message', { exact: true }).count(), 0);
  checks.push('cross-account storage update removes previous history/draft');
  await req('/auth/logout', { method: 'POST', token: c.accessToken });
  await page.getByRole('button', { name: 'Đăng nhập ngay', exact: true }).waitFor();
  checks.push('server logout revokes session and returns UI to login');
  assert.deepEqual(errors, []);
  console.log(JSON.stringify({ status: 'passed', checks, errors }, null, 2));
} catch (error) { console.error(error.stack); checks.push('FAILED: ' + error.message); process.exitCode = 1; }
finally { await browser?.close(); await writeFile(new URL('../reports/ui.json', import.meta.url), JSON.stringify({ date: new Date().toISOString(), checks, errors }, null, 2)); }
