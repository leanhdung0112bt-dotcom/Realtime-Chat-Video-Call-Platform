import { existsSync, readFileSync, writeFileSync, appendFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
function docker(args, capture = false) {
  const result = spawnSync('docker', ['compose', ...args], { cwd: root, encoding: 'utf8', stdio: capture ? 'pipe' : 'inherit' });
  if (result.error || result.status !== 0) throw new Error('Docker Compose thất bại: ' + (result.stderr || result.error?.message || result.status));
  return result.stdout;
}
let temporary;
try {
  docker(['version'], true);
  const file = new URL('../.env', import.meta.url);
  if (!existsSync(file)) writeFileSync(file, '# Local secrets; do not commit\n', { mode: 0o600 });
  const contents = readFileSync(file, 'utf8');
  const existing = Object.fromEntries(contents.split(/\r?\n/).filter(line => /^[A-Z_]+=/.test(line)).map(line => { const n = line.indexOf('='); return [line.slice(0, n), line.slice(n + 1).trim()]; }));
  const additions = [];
  for (const name of ['JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET']) {
    if (!(name in existing) && !process.env[name]) additions.push(name + '=' + randomBytes(48).toString('hex'));
    // Existing empty/weak values must be corrected explicitly, never overwritten.
  }
  if (!('APP_PORT' in existing) && !process.env.APP_PORT) additions.push('APP_PORT=3000');
  const port = process.env.APP_PORT || existing.APP_PORT || 3000;
  if (!('CORS_ORIGIN' in existing) && !process.env.CORS_ORIGIN) additions.push('CORS_ORIGIN=http://localhost:' + port);
  if (additions.length) appendFileSync(file, '\n' + additions.join('\n') + '\n');
  const options = ['-f', 'docker-compose.yml', ...(process.argv.includes('--single') ? ['-f', 'docker-compose.single.yml'] : [])];
  if (process.env.CODEX_PROXY_CERT) {
    temporary = mkdtempSync(join(tmpdir(), 'cki-build-'));
    const override = join(temporary, 'cloud-build.yml');
    writeFileSync(override, 'services:\n  server-a:\n    build:\n      secrets: [proxy_ca]\n  server-b:\n    build:\n      secrets: [proxy_ca]\n  client:\n    build:\n      secrets: [proxy_ca]\nsecrets:\n  proxy_ca:\n    file: ' + JSON.stringify(process.env.CODEX_PROXY_CERT) + '\n');
    options.push('-f', override);
  }
  // Parse config without logging secrets, and validate the effective values.
  const config = JSON.parse(docker([...options, 'config', '--format', 'json'], true));
  const env = config.services['server-a'].environment;
  if ([env.JWT_ACCESS_SECRET, env.JWT_REFRESH_SECRET].some(v => !v || v.length < 32) || env.JWT_ACCESS_SECRET === env.JWT_REFRESH_SECRET) throw new Error('Hai JWT secret phải khác nhau, mỗi secret ít nhất 32 ký tự.');
  docker([...options, 'up', '-d', '--build', '--wait', '--wait-timeout', '180', '--remove-orphans']);
  console.log('Ứng dụng sẵn sàng: http://localhost:' + port);
} catch (error) { console.error(error.message); process.exitCode = 1; }
finally { if (temporary) rmSync(temporary, { recursive: true, force: true }); }
