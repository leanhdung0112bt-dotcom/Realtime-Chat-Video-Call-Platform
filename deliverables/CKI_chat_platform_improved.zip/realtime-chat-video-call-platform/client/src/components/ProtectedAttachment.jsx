import { useEffect, useRef, useState } from 'react';
import api from '../services/api.js';
// Visible images are fetched with JWT. Documents download only after a click.
export function ProtectedAttachment({ attachment, compact = false }) {
  const [url, setUrl] = useState(null), [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0), [visible, setVisible] = useState(false);
  const element = useRef(null);
  const image = attachment.fileType?.startsWith('image/');
  const path = attachment.fileId ? '/files/' + attachment.fileId : attachment.url;
  const load = signal => api.get(path.startsWith('/uploads/') ? path : path.replace(/^\/api/, ''), {
    baseURL: path.startsWith('/uploads/') ? '' : api.defaults.baseURL, responseType: 'blob', signal,
  });
  useEffect(() => {
    const observer = new IntersectionObserver(entries => { setVisible(entries[0].isIntersecting); if (!entries[0].isIntersecting) setUrl(null); }, { rootMargin: '100px' });
    if (element.current) observer.observe(element.current);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (!image || !visible) return;
    let active = true, objectUrl;
    const controller = new AbortController();
    load(controller.signal).then(response => {
      if (!active) return;
      objectUrl = URL.createObjectURL(response.data); setUrl(objectUrl); setError('');
    }).catch(() => { if (active) setError('Không tải được ảnh — bấm để thử lại'); });
    return () => { active = false; controller.abort(); if (objectUrl) URL.revokeObjectURL(objectUrl); };
    // Attachment identity is immutable in one keyed component.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [image, visible, attempt, path]);
  const download = async () => {
    try {
      const response = await load();
      const objectUrl = URL.createObjectURL(response.data), link = document.createElement('a');
      link.href = objectUrl; link.download = attachment.fileName; link.click();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 1000); setError('');
    } catch { setError('Không tải được file — bấm để thử lại'); }
  };
  return <div ref={element} className="min-h-8">
    {error ? <button type="button" onClick={() => { setError(''); if (image) setAttempt(n => n + 1); else void download(); }} className="text-xs text-rose-300">{error}</button> : image ?
      <button type="button" onClick={() => void download()} title={'Tải ' + attachment.fileName} className="block rounded-lg overflow-hidden border border-white/10">
        {visible && url ? <img src={url} alt={attachment.fileName} className={compact ? 'w-12 h-12 object-cover rounded' : 'max-h-60 object-cover max-w-full'} /> : <span className="text-xs text-slate-400">Ảnh: {attachment.fileName}</span>}
      </button> : <button type="button" onClick={() => void download()} className="block p-2 text-xs truncate underline">Tải {attachment.fileName}</button>}
  </div>;
}
