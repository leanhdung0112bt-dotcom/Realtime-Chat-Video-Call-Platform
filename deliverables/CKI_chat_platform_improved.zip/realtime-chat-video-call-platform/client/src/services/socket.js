import { readTokens } from './session.js';
import { io } from 'socket.io-client';

import { SERVER_URL } from "./api.js";
let socket = null, reconnectTimer = null;
export function initSocket(_token) {
  if (!socket) {
    socket = io(SERVER_URL, {
      autoConnect: false,
      auth: callback => callback({ token: readTokens().accessToken }),
      transports: ['websocket'],
      reconnection: true, reconnectionDelay: 1000, reconnectionDelayMax: 5000,
    });
    socket.on('auth:revoked', () => window.dispatchEvent(new Event('auth:unauthorized')));
    socket.on('auth:expired', () => window.dispatchEvent(new Event('auth:expired')));
    socket.on('connect', () => { clearTimeout(reconnectTimer); reconnectTimer = null; });
    socket.on('connect_error', error => {
      if (error.data?.status === 503) {
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(() => { if (socket && !socket.connected) socket.connect(); }, 2000);
        return;
      }
      if (error.message.includes('Phiên đăng nhập')) window.dispatchEvent(new Event('auth:expired'));
    });
  }
  if (!socket.connected) socket.connect();
  return socket;
}
export const getSocket = () => socket;
export function disconnectSocket() {
  clearTimeout(reconnectTimer); reconnectTimer = null;
  socket?.removeAllListeners();
  socket?.disconnect();
  socket = null;
}

export function refreshSocket() {
  if (socket) { socket.disconnect(); socket.connect(); }
}
