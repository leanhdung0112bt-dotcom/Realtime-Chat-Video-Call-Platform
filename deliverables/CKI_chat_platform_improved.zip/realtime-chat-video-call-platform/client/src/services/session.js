// A version changes only when the account/session changes, not on token refresh.
let version = 0;
let controller = new AbortController();
export const sessionVersion = () => version;
export const isCurrentSession = expected => expected === version;
export const sessionSignal = () => controller.signal;
export function rotateSession() {
  version += 1;
  controller.abort();
  controller = new AbortController();
  return version;
}

// One storage write is the cross-tab commit point; never react to partially written token pairs.
export const SESSION_KEY = 'chat:session';
export function readTokens() {
  try {
    const record = JSON.parse(localStorage.getItem(SESSION_KEY));
    if (record?.accessToken && record?.refreshToken) return record;
  } catch { /* Legacy tokens are supported for an existing browser session. */ }
  return { accessToken: localStorage.getItem('accessToken'), refreshToken: localStorage.getItem('refreshToken') };
}
export function tokenIdentity(token) {
  try { return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).userId || null; }
  catch { return null; }
}
export function writeTokens(tokens) {
  const record = { ...tokens, userId: tokens.userId || tokenIdentity(tokens.accessToken) };
  localStorage.setItem('accessToken', tokens.accessToken);
  localStorage.setItem('refreshToken', tokens.refreshToken);
  localStorage.setItem(SESSION_KEY, JSON.stringify(record));
}
export function eraseTokens() {
  localStorage.removeItem('accessToken'); localStorage.removeItem('refreshToken');
  localStorage.removeItem(SESSION_KEY);
}
