# Kiến trúc triển khai của phần A

```mermaid
flowchart TD
  Browser[React/Vite/Zustand] <-->|REST, JWT, WebSocket-only| Edge[Nginx 1.28]
  Edge --> Static[Frontend static]
  Edge <--> A[server-a:5000]
  Edge <--> B[server-b:5000]
  A <-->|Pub/Sub Adapter| Redis[(Redis)]
  B <-->|Pub/Sub Adapter| Redis
  A --> Mongo[(MongoDB)]
  B --> Mongo
  A --> Storage[Uploads volume dùng chung]
  B --> Storage
```

Backend chạy ESM trực tiếp, không TypeScript/microservice. MongoDB là lịch sử bền vững; Redis giữ adapter, cache, hạn mức và lease presence. Command, pub, sub là ba kết nối riêng. Startup: validate secret → Mongo/index init → Redis → adapter + subscription barrier → sweeper → HTTP listen. Shutdown đặt readiness false, dừng sweeper, đóng socket/HTTP, Mongo và ba kết nối Redis; deadline 10 giây. SIGKILL không có graceful cleanup, lease xử lý crash.

## Tin nhắn và đồng bộ

REST/socket dùng chung message service. Quyền lấy từ `access.service.requireConversation`, người gửi từ JWT và người nhận suy ra từ hội thoại direct. Unique index `(conversationId,sender,clientMessageId)` và `$setOnInsert` giữ một bản ghi khi retry qua hai process. Retry không ghi lại timestamps/status. Nội dung khác trên cùng khóa bị 409. Preview chỉ tiến theo `(createdAt,messageId)`; seen chỉ nâng trạng thái. ACK `sent` nghĩa đã lưu MongoDB, không chứng minh delivered/seen. Adapter phát lại khi retry vẫn có thể tạo duplicate event; client gộp ID, không tuyên bố exactly-once E2E.

History dùng cursor `(createdAt,_id)`, tối đa 100/trang. Client reconnect tải từ mới nhất ngược tới anchor đã đồng bộ thành công, kể cả anchor null của hội thoại từng rỗng; chỉ commit khi tất cả trang thành công. Older-page request được đợi trước catch-up; lỗi giữ anchor/cursor cũ cho retry. Active history không tải toàn DB; phần đã chủ động tải vẫn giữ cho tới eviction. Cache tối đa 8 lịch sử hội thoại theo lần mở; lịch sử inactive không tự tăng theo stream; 20 draft trong RAM theo phiên và 5000 recent event IDs chống tăng unread khi retry. Active history có thể lớn nếu người dùng chủ động tải nhiều trang: chưa có virtualized list/hard cap trên hội thoại đang mở.

## Redis và policy lỗi

`config/redis.js` quản lý ioredis + adapter chính thức. RedisReady yêu cầu cả ba socket ready và subscription PING barrier; kết nối sub tự subscribe lại. Khi mất dependency, readiness/API/socket operation báo lỗi thay vì fallback local. Client nhận `server:degraded`; sau subscription phục hồi nhận `server:sync_required` để refresh contacts và tải bù. Publish có thể thất bại sau khi Mongo đã lưu: log `redis.publish_failed`, ACK vẫn mang nghĩa bền vững, không coi peer đã nhận. Redis Pub/Sub không có replay. Chưa có outbox hoặc transaction liên Redis/Mongo.

Profile cache dùng whitelist không password/tokenVersion/JWT và không cache online/lastSeen. Friend cache chỉ giữ relation IDs, hydrate profile và presence mỗi lần. TTL 60s, process metrics hit/miss/bypass/invalidation/rejectedFill ở `/api/diagnostics` có JWT. Invalidation là Redis `INCR epoch + DEL data`; fill chỉ được ghi bằng Lua nếu epoch không đổi. Một request đọc đã bắt đầu trước update có thể trả snapshot cũ; request sau mutation/invalidation thành công đọc dữ liệu mới. Nếu Redis rơi đúng giữa DB write/invalidation thì TTL là giới hạn stale; request có thể báo lỗi dù DB đã đổi. Epoch và presence state hash được giữ bền trong Redis để tránh ABA/reset version; cần giám sát dung lượng và quản lý theo vòng đời tài khoản khi hệ thống có xóa user. Không dùng cache cho auth/quyền.

Rate limit fixed-window Redis Lua: 30 auth/IP/phút, 20 upload/user/phút, 120 message và 120 typing/user/phút, 600 socket events/user/phút. REST và socket message chung quota. Nginx ghi đè X-Forwarded-For, backend nội bộ tin đúng một hop; local không tin header proxy. Fixed window có burst tại ranh giới, không phải chống DDoS hoàn chỉnh.

## Presence phân tán

Mỗi user có sorted set các socketID → lease expiry; Redis Lua prune lease hết hạn, touch/remove socket, chuyển online/offline nguyên tử và cập nhật sorted set `presence:due`. Hash state có online/lastSeen/version. Sweeper mỗi backend kiểm tra tối đa 200 user tới hạn mỗi 5s; Lua bảo đảm chỉ một transition được phát dù nhiều sweeper. REST profile/friend/conversation dùng cùng phép đọc/prune, không tin Mongo `isOnline` cũ. Một tab đóng chỉ xóa lease tab đó; còn lease khác thì vẫn online.

Heartbeat 10s, lease 45s. Khi backend chết, thông thường offline trong tối đa khoảng 50s kể từ heartbeat cuối nếu còn một backend sống và Redis/Mongo hoạt động. Nếu 1000 user cùng hết hạn, backlog 200/lượt có thể cần thêm khoảng 25s; không cam kết 50s bất kể tải. Không cần keyspace notification. LastSeen là thời điểm hệ thống xác nhận không còn lease hợp lệ (disconnect hoặc sweep/read sau expiry), không phải lần gõ phím cuối. Chỉ transition offline ghi Mongo; heartbeat không ghi DB. Lỗi Redis trả `presenceAvailable=false` trong helper, runtime readiness vẫn false. Version bảo vệ thứ tự transition trên client; full Redis data loss cần re-sync REST và không coi đó là restart không mất dữ liệu.

## File

Upload authorization chạy trước Multer. File streamed vào disk; chỉ đọc tối đa 8 KB cho signature. Metadata Upload có uploader/conversation/storedName/originalName/MIME/size/state/messageKey/timestamps. Message service lấy metadata server và claim file cho khóa message, không cho gửi file của người khác hoặc hội thoại khác. URL tải có JWT và quyền tại thời điểm tải. Owner preview pending, peer cần message reference; attachment response/Blob URL được hủy theo component/session; chỉ ảnh trong vùng nhìn mới tải, tài liệu tải khi click.

Cleanup không TTL: grace ≥1h vượt upload HTTP timeout, optimistic claim `deleting` theo updatedAt, kiểm tra message references trước/sau claim, unlink rồi xóa metadata. Crash ở giữa có thể chạy lại. Legacy chỉ tải nếu message reference chứng minh quyền; không scan/xóa tùy tiện file cũ không rõ nguồn. Chữ ký không chứng minh file an toàn hoặc cấu trúc đầy đủ.

## Giới hạn và phần B

Group/GroupMember có trong source; chưa nối vào luồng nghiệp vụ. Signaling vẫn là scaffold, không quản lý callId/busy/timeout. B mở rộng đúng access helper cho GroupMember và thu hồi room khi membership đổi; adapter không tự quản lý quyền nhóm/cuộc gọi. Xem INTEGRATION_B.md. MongoDB một node, Redis một node, shared local volume và một Nginx chưa đáp ứng HA, failover host, backup hay khôi phục thảm họa.
