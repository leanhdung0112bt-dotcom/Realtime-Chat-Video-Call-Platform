# Kế hoạch test và tái lập

Node host đã dùng 24.22.1, Docker rootless 29.9.2, Compose 2.40.3, Mongo 7, Redis 7, Nginx 1.28; runtime container Node 22. Tất cả lệnh dưới chạy tại gốc trừ khi ghi khác. Kết quả phiên bàn giao: REVIEW_NOTES và reports, không suy từ kết quả lịch sử README cũ.

## Baseline và kiểm tra nhanh

```bash
npm --prefix server ci
npm --prefix client ci
npm ci  # công cụ Playwright của root, không cần cho docker:up
npm run check:server
npm test
npm run build:client
npm --prefix client run lint
```

Unit/HTTP/client gồm stub/model query, axios adapters và store logic; không thay integration. Có ca stale response/refresh nhiều401, account change, reconnect nhiều trang/anchor null/older-page song song/lỗi giữa trang, seen/preview, draft/quyền file/signature. Baseline chạy trên source ZIP nguyên gốc riêng, dependency cài ở máy này; không xem pass cũ trong README là lần chạy mới. `reports/baseline-*` ghi lượt baseline sau khắc phục quyền mạng cài dependency.

## Integration thật, không chạm dữ liệu bên ngoài

```bash
npm run test:integration
```

Harness tự tạo container Mongo/Redis tên `cki_test_<run>`, random host port loopback cố định qua restart, DB và REDIS_PREFIX riêng, uploads temp, JWT secrets tạm. Hai process Node riêng với INSTANCE_ID khác nhau, cùng DB/Redis/storage. Chỉ dọn DB có tên đúng runId, containers/anonymous volumes do test tạo và temp dir; không FLUSH* hoặc xóa dữ liệu khác. Cần Docker daemon và images mongo:7.0/redis:7-alpine (Docker tự pull khi thiếu). Cổng free kiểm tra trước bind vẫn có race OS, lỗi phải được báo, không bỏ test.

Các ca: message/seen/typing/history xuyên A/B; retry đồng thời và conflict; preview/seen không lùi; presence multi-tab/last close/SIGKILL/TTL/reconnect; cache hit/miss/TTL/profile/friend invalidation và fill race; file owner/member/outsider/metadata giả/signature/20 MiB/legacy/orphan dry-run/apply; history>150/cursor; quota typing/auth/upload chung; Redis stop/start, subscription phục hồi và module socket client thật tự nối lại từ handshake503; JWT expiry timer/refresh/logout mọi backend.

Timing test rút ngắn: lease1500ms, heartbeat400ms, sweep200ms, cache2s; RATE_MESSAGE1000/phút để thử161 tin mà không chờ. Runtime demo vẫn45s/10s/5s/cache60s và quota120 tin/phút. Không dùng timing test để tuyên bố phát hiện crash demo trong2 giây.

## Nginx / Docker / volume

Dùng stack cô lập. Các lệnh POSIX sau không cần sửa `.env` có sẵn; docker:up bổ sung secret khi thiếu:

```bash
COMPOSE_PROJECT_NAME=cki-review APP_PORT=3100 CORS_ORIGIN=http://localhost:3100 npm run docker:up
BASE_URL=http://localhost:3100 npm run test:smoke
BASE_URL=http://localhost:3100 COMPOSE_PROJECT_NAME=cki-review TEST_RECREATE=1 npm run test:proxy
BASE_URL=http://localhost:3100 CHROMIUM_PATH=/usr/bin/chromium npm run test:ui
COMPOSE_PROJECT_NAME=cki-review docker compose down
```

Không down-v. Tests API/UI trên stack này để lại tài khoản `smoke_*`, `proxy_*`, `ui_*` trong volume riêng để kiểm tra, không chạy trên production. Proxy test dùng server:info để đếm phân phối socket thật, gửi cross-instance, tải cùng file qua cả instance và chặn outsider. TEST_RECREATE chỉ cho project `cki-*`: remove riêng server-b, tạo peer tạm giữ địa chỉ, dựng B lại, ghi IP trước/sau và yêu cầu cả hai instance hoạt động. Nếu IP không thực sự đổi thì không coi ca DNS đổi-IP là đã kiểm chứng. Shared volume còn đọc được sau recreate.

`docker:up:single` sau `down` phải cho đúng một backend và vẫn giữ data. Sau đó down rồi docker:up trở lại hai backend. `docker compose config --quiet` không in secret; không đưa output config đầy đủ vào báo cáo.

## UI thực

Cài root npm ci; `npx playwright install chromium` hoặc trỏ `CHROMIUM_PATH` tới Chromium/Chrome đã cài. Kịch bản hiện có chạy desktop1280×800 và mobile390×844, đăng nhập/gửi, mạng lỗi giữ draft và retry, upload ảnh/Blob, offline rồi tải bù161 tin qua MongoDB/REST thực với quota demo, refresh cùng tài khoản nhiều tab giữ draft, chuyển tài khoản bỏ history cũ, logout từ server trở về login. Không coi Playwright smoke là nghiệm thu mọi thiết bị/trình duyệt hoặc camera/mic/WebRTC.

## Đo tải

```bash
CLIENTS=20 BACKENDS=1 WARMUP=1 DURATION=5 SEED=42 npm run test:load
CLIENTS=100 BACKENDS=1 WARMUP=3 DURATION=15 SEED=42 npm run test:load
CLIENTS=100 BACKENDS=2 WARMUP=3 DURATION=15 SEED=42 npm run test:load
# Lặp500/1000 khi tài nguyên và độ trễ máy phát tải phù hợp; đo tuần tự, không song song.
```

Không chạy integration/build/UI đồng thời với benchmark cần so sánh chặt chẽ. Workload default20% senders,1 tin/s/sender,128 ký tự ASCII, JWT/các quyền giữ nguyên. Seed DB thay cho bão đăng ký nên không đo login/bcrypt. Hai process backend share một máy với generator; không áp cgroup limit; đó là tổng ngân sách chung, không phân bổ CPU gấp đôi khi thêm instance. `/proc` và getconf đo CPU ticks/RSS từng backend, process.cpuUsage/RSS/lag cho generator; Redis INFO cpu/memory; Mongo serverStatus CPU/mem. Generator dùng một đồng hồ monotonic nên không lệch đồng hồ giữa máy. JSON có config/runId/date/commit hoặc null nếu ZIP không Git, CPU model/count/RAM và raw resource samples. CSV tóm tắt số liệu latency, ACK, realtime/catch-up/DB IDs.

ACK p50/p95 gồm đường JWT/rate/quyền/DB/broadcast tại server. Peer p50/p95 là first matching message:received tại peer; không tính echo người gửi. Đếm duplicate realtime event, missing realtime trước tải bù, missing sau REST cursor và bản ghi acknowledged thiếu/trùng ở DB. Mất ACK có thể vẫn lưu: đối chiếu riêng, không gọi lỗi ACK là không ghi. Đo15 giây không là benchmark dài hạn hoặc giới hạn saturation; muốn capacity cần soak, tăng send rate, media/file workload, quotas đã thống nhất và máy phát tải riêng. Không tự hứa1000 user production.

## Chờ B và chưa nghiệm thu

Chat nhóm end-to-end, thu hồi GroupMember room/file, WebRTC lifecycle/media/TURN giữa thiết bị khác mạng: chờ B. HTTPS template có cấu hình nhưng chưa chạy chứng chỉ domain thật. HA/replica set/Redis Sentinel/multi-host shared storage, virus scanner, soak dài và test tất cả browser: chưa thực hiện, không báo pass.
