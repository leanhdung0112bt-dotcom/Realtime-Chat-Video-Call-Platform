# Số đo tải thực tế (ngắn)

Chạy Linux, Node 24.22.1, Mongo 7/Redis 7 trong Docker, backend process riêng và generator trên cùng máy: 5 CPU AMD EPYC9V74 được môi trường báo, RAM khoảng33.29 GiB. Không có quota cgroup riêng cho process; một/hai backend dùng cùng tổng máy, không gấp đôi ngân sách. Một stack demo khác idle trong máy. Các lượt này không là capacity/soak dài;15s không chứng minh1000 người dùng production.

100/500/1000: WARMUP3s, DURATION15s, SEED42,20% senders,1 tin/s/sender,128 ASCII bytes, JWT/permission/rate mặc định. Smoke20: warmup1s/run5s. Các mức được chạy tuần tự, không chạy hai workload so sánh song song. Trong phiên có các thao tác phát triển khác, nên số đo là bằng chứng chạy thực và tham khảo, không là benchmark môi trường phòng thí nghiệm cô lập. ACK/peer dùng đồng hồ monotonic chung, peer không tính sender echo; catch-up đo riêng. Mỗi sender dùng một hội thoại với bạn đã accepted. Tài khoản được seed trong DB test; không đo throughput login/bcrypt.

| Connections | Backend | Gửi / ACK OK / ACK lỗi | ACK p50 / p95 ms | Peer p95 ms | Tổng backend CPU giây | Backend RSS cuối MiB | Generator RSS peak MiB | Missing realtime / sau catch-up / DB trùng |
|---|---|---|---|---|---|---|---|---|
| 20 | 1 | 20 / 20 / 0 | 13.54 / 17.99 | 18.05 | 0.24 | 120.1 | 94.4 | 0 / 0 / 0 |
| 100 | 1 | 300 / 300 / 0 | 8.35 / 16.86 | 16.63 | 1.78 | 144.9 | 105.8 | 0 / 0 / 0 |
| 100 | 2 | 300 / 300 / 0 | 9.92 / 19.53 | 20.42 | 2.49 | 278.7 | 115.1 | 0 / 0 / 0 |
| 500 | 1 | 1500 / 1500 / 0 | 7.40 / 15.24 | 15.24 | 5.47 | 238.5 | 138.3 | 0 / 0 / 0 |
| 500 | 2 | 1499 / 1499 / 0 | 8.38 / 16.22 | 17.20 | 6.95 | 441.0 | 144.4 | 0 / 0 / 0 |
| 1000 | 1 | 3000 / 3000 / 0 | 8.18 / 25.08 | 25.03 | 8.96 | 312.3 | 163.3 | 0 / 0 / 0 |
| 1000 | 2 | 3000 / 3000 / 0 | 8.58 / 20.61 | 22.02 | 11.84 | 474.1 | 168.6 | 0 / 0 / 0 |

Redis CPU/usedMemory/peak và Mongo user_time_us/system_time_us/residentMB, raw backend samples, scheduling lag của generator có trong JSON tương ứng; CSV để tái sử dụng. 1499 thay1500 ở một lượt500 là số message scheduler phát thực trong cửa sổ, không được bù giả số. Không có ACK errors/missing sau catch-up/DB duplicate ở các lượt thành công trên. Không suy tỉ lệ tăng tốc từ số container; ở100/500, hai backend không nhanh hơn một backend trong phép đo này.

Một lần1000/hai backend chưa bắt đầu workload vì Docker rootless chọn port đang bận. JSON failure được giữ nguyên, không tính vào kết quả pass. Harness đã chuyển sang cổng loopback được chọn bằng net.listen và đăng ký container để cleanup kể cả docker run thất bại; lượt retry thành công có file JSON/CSV riêng.

Đường Nginx được kiểm tra riêng bằng proxy.json/proxy-two.json/proxy-single.json, không gộp vào latency của harness pin trực tiếp process. Hệ thống chưa đo file tải lớn, call media, WAN, mất gói, soak dài hoặc saturation. Nhóm/cuộc gọi chờ B.
