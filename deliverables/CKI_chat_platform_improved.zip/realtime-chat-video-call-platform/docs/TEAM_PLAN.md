# Phân công A / B

| Chủ việc | Phạm vi | Tình trạng bản bàn giao |
|---|---|---|
| A | Auth/chat cá nhân và reliability, metadata/quyền file, Redis Adapter/cache/rate/presence, Docker/Nginx, integration, tải và tài liệu hạ tầng | Đã triển khai; kết quả thực tế và giới hạn trong REVIEW_NOTES / reports |
| B | Toàn bộ chat nhóm backend/frontend, quyền/roles, read state nhóm, Audio/Video WebRTC 1–1, call lifecycle, test/demo/tài liệu riêng | Chờ module B, giữ model/scaffold hiện có |
| Hai người | Review file chung, nghiệm thu sau merge, báo cáo đồ án | Chưa nghiệm thu nhóm/cuộc gọi |

Không đổi TypeScript/stack hoặc tách microservice. Không thêm gọi nhóm/screen sharing/admin/bot/broker. Group/GroupMember giữ nguyên; phương án GroupMember là nguồn quyền nhóm, Conversation.groupId và read cursor theo member chỉ là đề xuất phải do B chốt và migration.

Các file có nguy cơ xung đột: sockets/socket.js, sockets/events.js, services/message.service.js, app.js, index.js, models/Message.js, models/Conversation.js, App.jsx, ChatArea.jsx, Sidebar.jsx, stores, package.json/lockfiles. Xem INTEGRATION_B.md để ghép adapter, user rooms, helper quyền và file contract. A không tự push/merge/deploy hoặc thay công việc B. Mọi nghiệm thu báo cáo theo hành vi đã chạy thật, không tự chấm điểm hoặc suy phần trăm từ số test.
