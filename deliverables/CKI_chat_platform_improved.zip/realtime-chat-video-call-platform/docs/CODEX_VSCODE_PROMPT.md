# Prompt tiếp tục rà soát

Đọc source hiện tại, AGENTS.md nếu có và README / ARCHITECTURE / API_DOCUMENTATION / TEST_PLAN / TEAM_PLAN / INTEGRATION_B / REVIEW_NOTES trước khi sửa. Giữ mọi thay đổi mới của đồng đội và người dùng; không reset/clean hoặc ghi đè để quay về ZIP cũ.

Phạm vi A đã mở rộng gồm Redis Adapter, cache/invalidation, lease presence, rate limit dùng chung, metadata/quyền file, Docker/Nginx nhiều backend và workload đo tải. Không áp dụng giới hạn cũ chỉ ổn định một backend. Nhóm và WebRTC thuộc B; không tự chọn schema thay B, giữ Group/GroupMember/scaffold.

Tiếp tục bằng npm ci đúng các package/lockfile (root cần cho UI test), syntax/unit/build/lint. Integration phải là hai process với MongoDB/Redis thật, namespace/DB/uploads riêng; không coi stub là E2E. Test Nginx phải xác minh server:info/X-Instance-Id và DNS sau recreate. Kiểm tra cross-tab, ACK retry, history nhiều trang, file permissions/legacy/cleanup. Không tắt auth/rate/assertion để tạo số đẹp. Đọc reports hiện có như lịch sử; chạy mới và ghi rõ môi trường/kết quả mới.

Tải ngắn không là soak/capacity production. Benchmark giữ workload/seed/budget, theo dõi generator, tách realtime/catch-up và ghi lỗi. Nếu thiếu môi trường thì ghi bị chặn, không bịa số liệu. Không push/merge/deploy hoặc xuất bản môi trường khi chưa được yêu cầu. Bàn giao source sạch secrets/node_modules/dist/cache/data và một báo cáo tiếng Việt với giới hạn thật.
