# Contract REST và Socket.IO

JSON REST thành công `{success:true,data}`, lỗi `{success:false,message}`. Dùng `Authorization: Bearer <accessToken>`; không truyền JWT trong URL. Token access 15 phút, refresh 7 ngày, secrets khác nhau ≥32 ký tự. Mọi authenticated request kiểm tra User.tokenVersion trực tiếp MongoDB; logout thu hồi mọi thiết bị. Network failure khi logout chỉ có thể xóa phiên local, chưa chứng minh server đã thu hồi.

## Auth và bạn bè

| Method / path (prefix /api) | Body / kết quả |
|---|---|
| POST /auth/register | username,email,password,avatar? → user/accessToken/refreshToken; 201 |
| POST /auth/login | identifier,password → user/accessToken/refreshToken |
| POST /auth/refresh-token | refreshToken → accessToken/refreshToken; 401 nếu bị thu hồi |
| GET /auth/me | profile whitelist + presence hiện tại, không tokenVersion |
| PUT /auth/profile | username?,avatar?,bio?; invalidate profile cache |
| POST /auth/logout | tăng tokenVersion, auth:revoked và disconnect user room xuyên instance |
| GET /friends/search?query= | tối đa 20, relationship/friendshipId và presence |
| GET /friends/all | `[ { friendshipId,user,since } ]`, friend cache + profile + Redis presence |
| GET /friends/requests | received/sent |
| POST /friends/request | recipientId; 201 lời mời, 200 khi chấp nhận lời mời ngược |
| PUT /friends/request/:id/accept | chỉ recipient pending |
| DELETE /friends/request/:id/decline | hủy/từ chối pending |
| DELETE /friends/:friendId | xóa quan hệ; invalidate cache hai phía; giữ lịch sử hội thoại |

## Hội thoại/tin nhắn

- GET `/messages/conversations`: direct conversations + friend/presence/preview/unread.
- GET `/messages/conversation/:friendId`: tạo/lấy direct khi đã là bạn bè.
- GET `/messages/:conversationId?limit=50&before=cursor`: data tăng dần trong trang; pagination `{nextCursor,hasMore}`. Không đánh dấu seen khi đọc HTTP.
- POST `/messages/send`: `{conversationId,text?,attachments?:[{fileId}],clientMessageId}`; recipientId nếu gửi kèm phải khớp stored membership. 201, kể cả retry cùng nội dung. Text ≤4000 ký tự, ≤5 file. Nên luôn giữ clientMessageId 8–100 ký tự `[A-Za-z0-9_-]` cho retry; server sinh UUID nếu client cũ không gửi nhưng khi đó client không có khóa để retry chính xác.
- PUT `/messages/:conversationId/seen`: `{lastReadMessageId}` → messageIds/seenAt; chỉ đánh dấu tin nhận tới mốc đã hiển thị.

`status=sent` là lưu bền vững, `seen` có xác nhận đọc; không tự set delivered chỉ vì online. Membership direct là quyền truy xuất lịch sử/send trong hội thoại đã có, kể cả khi bỏ kết bạn; yêu cầu accepted friendship chỉ áp dụng lúc mở/tạo direct theo friendId. Không có policy block user hoàn chỉnh. Retry cùng ID nội dung khác →409. Preview có `messageId` mới, dữ liệu cũ có thể chưa có trường đó.

## Upload/download (contract mới)

POST `/upload/:conversationId` với multipart **một field file duy nhất tên `file`**, JWT; quyền được kiểm tra trước ghi file. Không cần/không nhận conversationId trong multipart. Route cũ POST `/upload` trả400 hướng dẫn mới. 20 MiB/file, tối đa5/tin. Allowlist: JPEG/PNG/GIF/WebP/PDF/DOC/DOCX/TXT/MP4/MP3/WAV; signature 8KB không phải malware scan, DOCX chỉ kiểm tra vỏ ZIP.

201 `{success:true,data:{fileId,url:'/api/files/<id>',fileType,fileName,fileSize}}`. Gửi message bằng fileId; client có thể giữ metadata này cho preview, nhưng metadata giả bị400 và owner/conversation sai bị403, file đang dọn hoặc bị bind tin khác bị409.

GET `/files/:fileId` cần JWT và quyền hội thoại hiện tại; owner xem file chưa gửi, peer chỉ sau message reference, outsider403, metadata không có/deleting404. Response attachment với nosniff, sandbox CSP và private/no-store. Frontend lấy Blob bằng request có Authorization, không `<img src>` trực tiếp tới API và không JWT query string. Blob ảnh chỉ tải trong vùng nhìn, dọn khi unmount/rời vùng nhìn. File khác tải theo click.

GET `/uploads/:storedName` là compatibility route có JWT. Metadata mới dùng quyền mới; legacy không metadata chỉ được tải qua message reference với membership thật, MIME octet-stream. Không có public static uploads. File legacy không đủ chứng cứ quyền bị403; không tự xóa hoặc tin owner/MIME do client gửi.

## Socket

Auth handshake `{auth:{token}}`, **transports:['websocket']**. Không có polling fallback/sticky session. Handshake khi dependency lỗi trả connect_error.data `{status:503,code:DEPENDENCY_UNAVAILABLE}`; client tự thử lại sau2s, không coi là hết phiên. JWT kiểm tra khi connect và mỗi event; timer đóng socket tại expiry, heartbeat kiểm tra revocation bổ sung. User room `user:<id>` là địa chỉ ổn định cho mọi thiết bị/instance. Helper emitToUsers phát vào hợp các rooms, không phát trùng do loop user IDs.

| Client emit | Payload |
|---|---|
| conversation:join / leave | conversationId string; join kiểm tra quyền |
| message:send | cùng body REST, ACK `{success:true,message}` |
| message:seen | conversationId,lastReadMessageId |
| typing:start / stop | conversationId, không tin recipient từ client |

ACK lỗi `{success:false,error,status,code}`; code RATE_LIMITED cho429, DEPENDENCY_UNAVAILABLE cho503, REQUEST_FAILED cho lỗi khác. Các event ngoài message ACK thành công gộp result trong `{success:true,...result}`. Không có callback thì server phát operation:error `{message}`. Socket payload tối đa100KB, JSON HTTP tối đa256KB.

Server emits: `server:info {instanceId,socketId}`, `message:received` message DTO, `message:seen_ack {conversationId,seenBy,seenAt,messageIds}`, `typing:status {conversationId,userId,username,isTyping}`, `user:presence {userId,isOnline,lastSeen,presenceVersion,presenceAvailable}`, `friend:request_received`, `friend:request_accepted {conversationId}`, `friend:changed`, `auth:expired`, `auth:revoked`, `server:degraded {reason:'redis'}`, `server:sync_required`. Sau sync_required client tải bù REST; không coi Pub/Sub có replay.

Scaffold `call:initiate/answer/ice-candidate/reject/end` còn được giữ để B nối; chưa là WebRTC hoàn chỉnh, chưa nghiệm thu. Không có API nhóm đầy đủ.

## Vận hành

GET `/health`: process alive + instanceId. GET `/ready`: 200 chỉ khi MongoDB connected, Redis command/pub/sub + subscription barrier ready và chưa shutdown; nếu không503. HTTP header X-Instance-Id và server:info dùng xác minh backend thật. GET `/api/diagnostics` có JWT → instanceId/cache counters cục bộ (không nội dung cache). Lỗi dependency503, validation400, auth401, quyền403, không có404, xung đột409, rate429. Hạn mức dùng Redis fixed windows, chi tiết README.
