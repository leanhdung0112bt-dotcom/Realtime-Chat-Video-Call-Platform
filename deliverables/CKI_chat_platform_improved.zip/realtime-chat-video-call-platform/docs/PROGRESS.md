# Checkpoint bàn giao

- Baseline36 tests đạt trên source ZIP nguyên gốc, có log riêng.
- Phần A đã triển khai: Redis Adapter/cache/lease presence/quota, quyền file/cleanup, idempotent chat/session multi-tab, Docker/Nginx1/2 backend, integration/load/UI và tài liệu ghép B.
- Kiểm chứng:44 unit/client/HTTP tests,10 nhóm integration thật, UI desktop/mobile8 luồng (161 tin catch-up), proxy/DNSrecreate/sharedvolume và load ngắn100/500/1000. Kết quả và giới hạn ở REVIEW_NOTES / BENCHMARK_RESULTS / reports.
- Các lỗi setup/test gặp trong phiên được giữ bằng chứng và chẩn đoán; không đổi assertion/auth để làm đẹp số.
- Group/GroupMember và contract emitToUsers giữ nguyên; nhóm/WebRTC/TURN chờ B. HTTPS template chưa có cert/domain để chạy.
- Đã xác minh thêm source sạch chưa có .env/node_modules khởi động một lệnh, sinh secret và sáu service ready; audit index chỉ đọc đạt.
- Không push/merge/deploy hoặc áp lại/publish cấu hình môi trường. ZIP gốc/repo Git được giữ nguyên; source bàn giao sạch secrets/dependency caches và dữ liệu.
- Để tiếp tục: đọc REVIEW_NOTES, INTEGRATION_B và TEST_PLAN; không coi kết quả phiên này là kết quả cho một merge/code mới chưa chạy.
