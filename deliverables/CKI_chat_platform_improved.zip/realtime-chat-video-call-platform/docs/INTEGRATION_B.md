# Hướng dẫn ghép phần B

B giữ quyền quyết định thiết kế nhóm/cuộc gọi. Không có triển khai nhóm/WebRTC thay thế trong lần A này.

## Helper và lifecycle dùng chung

- `server/src/sockets/events.js`: `emitToUsers(ids,event,payload)` phát một lần vào union user rooms, Redis Adapter tự chuyển xuyên instance. Không thêm manual Pub/Sub cho cùng event. `getIO()` cho thao tác adapter như `io.in(room).disconnectSockets(true)` hoặc `socketsLeave`.
- `server/src/config/redis.js`: `command` dùng cache/lease/rate/call state, `pub`/`sub` dành adapter. Dùng `prefix` với namespace mọi key của B; không dùng sub cho GET/SET. Runtime đóng kết nối tập trung tại index.js, không tạo client không được dọn.
- `presence.service.js`: `presenceFor(userId,fallback)` là nguồn online hiện tại; socket heartbeat/sweeper đã quản lý lease. Online không nghĩa peer đã nhận hoặc đang rảnh cho cuộc gọi. Không đặt Map onlineUsers mới.
- `cache.service.js`: `cached(key,loader)`, `invalidate(...keys)`. Không cache tokenVersion/quyền nhóm hoặc secret. `profile.service.js` hydrate profile/presence và invalidate quan hệ hai phía.
- **Điểm quyền** `access.service.requireConversation(userId,conversationId)` hiện chỉ direct, được dùng chung message/upload/download/legacy. B phải thêm kiểm tra membership thực tế theo thiết kế nhóm của B. Không chỉ nhìn Conversation.participants nếu nguồn quyền nhóm là GroupMember. Re-export từ message.service giữ import cũ.

## Contract file và message

1. Frontend POST `/api/upload/:conversationId` với JWT và file multipart; nhận `{fileId,url,fileType,fileName,fileSize}`.
2. Gửi tin với attachment `{fileId}`. Server lấy metadata từ Upload, uploader và conversation phải khớp; metadata giả bị400. Cùng file được bind với một clientMessageId, retry dùng lại đúng ID. Nếu thay nội dung/attachments sau lần gửi chưa rõ ACK, đó là lần gửi khác: tạo ID mới và upload mới nếu file đã bind ID trước.
3. Tải `/api/files/:fileId` qua Authorization/Blob. Dùng `ProtectedAttachment.jsx`, không token trong URL và không static/public uploads. Owner preview pending; member cần message reference. Mở rộng requireConversation sẽ áp dụng quyền nhóm cả upload và download; khi rời nhóm phải mất quyền tải mới.
4. Message service normalize chung ≤4000 ký tự, 5 file. Message attachment thêm `fileId` nhưng giữ url/fileType/fileName/fileSize để đọc dữ liệu cũ. Conversation.lastMessage thêm messageId cho thứ tự tie-break; không đổi nhóm schema.
5. ACK socket lỗi `{success:false,error,status,code}`; sent nghĩa lưu Mongo. REST/socket gửi cùng clientMessageId qua nhiều instance phải là cùng bản ghi. Không tin sender/recipient/owner do client cung cấp.

## Nhóm và cuộc gọi

Source giữ Group `{name,avatar,creator,description}` và GroupMember `{groupId,userId,role,joinedAt}` unique `(groupId,userId)`; chưa có groupId trong Conversation và Message.recipient vẫn bắt buộc. Các đề xuất GroupMember làm nguồn quyền, read cursor theo member là **đề xuất**, chưa tự áp dụng. B thiết kế migration riêng rồi mới sửa schema này.

Khi xóa thành viên: thu hồi conversation/group rooms trên **tất cả backend** bằng adapter; dừng call participation theo call service của B. User room dùng cho thông báo riêng/logout, không phải quyền nhóm tự động. Các event phát nhóm phải dựa membership hiện tại; adapter không tự lọc người đã rời.

Signaling scaffold vẫn tồn tại, không có callId/busy/timeout/ICE lifecycle đầy đủ. B triển khai call lifecycle có khóa/TTL/atomic state nếu chạy nhiều backend; không dùng Map busy riêng process. Redis Adapter chỉ định tuyến. HTTPS/STUN/TURN hướng dẫn trong HTTPS_AND_TURN.md; TURN long-term secret ở server, cấp credential ngắn hạn cho người có quyền, không nhúng vào bundle.

## Các file chung A đã chạm

`socket.js`, `message.service.js`, `Message.js` (attachment fileId), `Conversation.js` (lastMessage.messageId), `app.js`, `index.js`, controllers auth/friend/message/upload, package/lockfiles, App.jsx, ChatArea.jsx, Sidebar.jsx, auth/chat store và services api/session/socket. `events.js`, Group.js, GroupMember.js và FriendView.jsx không bị viết lại.

Sau merge: chạy syntax → unit/client → build/lint → `test:integration` → `test:proxy` trên stack riêng → `test:ui`; B bổ sung ca thêm/xóa/rời nhóm và file sau thu hồi membership, callId/busy/timeout/hangup, hai thiết bị/khác mạng/TURN. Chưa có các ca đó thì ghi chờ B, không tuyên bố toàn đồ án đạt cấp kỹ thuật.
