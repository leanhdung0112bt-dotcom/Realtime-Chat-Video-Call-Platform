# HTTPS, STUN và TURN để B tích hợp

Localhost có thể demo HTTP. Khi có domain, cấu hình DNS/cert và expose Nginx443. File `nginx/https.conf.example` là template; thay domain và đường cert, mount read-only cert/key, mở443 trong Compose override và đặt CORS_ORIGIN=https://domain. Giữ upstream zone/Docker resolver và file upstream từ default.conf. Nginx frontend vẫn ở mạng nội bộ. Kiểm tra `nginx -t`, HTTPS health/ready và WebSocket upgrade sau khi có cert thật. Không có cert/domain được cấp trong lần kiểm thử này; template chưa là deployment đã chạy.

Dùng chứng chỉ CA hợp lệ, renewal và backup key ngoài source. Không đặt certificate private key/JWT secret vào image hoặc ZIP. HSTS chỉ bật khi HTTPS toàn bộ domain đã xác minh, không bật trên demo HTTP.

WebRTC do B: HTTPS cho getUserMedia ngoài localhost; STUN giúp phát hiện candidate nhưng không đảm bảo kết nối qua NAT. TURN cần có hostname, cổng UDP/TCP/TLS và relay range phù hợp mạng triển khai. B cấu hình server `TURN_URLS`, `TURN_REALM`, `TURN_SHARED_SECRET`, TTL credentials và một API cấp ICE credentials ngắn hạn cho tài khoản có quyền. Đây là **đầu mối cấu hình đề xuất cho B**, hiện chưa có API cấp ICE hoặc TURN server trong Compose; không ghi đã triển khai WebRTC.

Không truyền TURN_SHARED_SECRET qua biến VITE_ hoặc bundle. Với coturn shared-secret mechanism, server tạo username expiry:userId và HMAC credential thời hạn ngắn; client chỉ nhận urls/username/credential đã cấp. B quản lý callId, busy, timeout, hangup, cleanup media tracks và ràng buộc signaling vào cuộc gọi hợp lệ. Redis Adapter chỉ chuyển events, không thay call lifecycle hoặc media relay. Khi có môi trường, nghiệm thu cả kết nối trực tiếp và relay-only, hai thiết bị khác mạng và trường hợp TURN hỏng.
