# Bàn giao phần A — kết quả thực tế

Làm từ ZIP người dùng gửi, giải nén riêng, giữ ZIP gốc và repository Git `hi` không thay đổi. Không tự tạo nhóm/WebRTC, push, merge, deploy public hoặc thay bản nháp môi trường. JavaScript/JSX và giao diện nền được giữ; mobile chỉ sửa bố cục/nút trở lại cần thiết.

## Chức năng đã triển khai

- Redis command/pub/sub riêng, official Socket.IO Redis Adapter, namespace, subscription ACK/PING barrier, reconnect, error handling và shutdown. `emitToUsers` giữ nguyên contract. Redis lỗi làm readiness/API/event fail-closed; client đang nối nhận degraded/sync_required, client bị từ chối handshake503 tự thử lại2s. MongoDB là nguồn lịch sử; không coi ACK là peer đã nhận hoặc exactly-once E2E.
- Cache profile whitelist + friend relation IDs thực sự dùng ở GET me/friends; hydrate presence từ Redis. TTL/invalidation chung; epoch CAS chặn stale fill sau mutation. Auth/tokenVersion/quyền không dùng cache. Hit/miss và race được kiểm tra.
- Presence lease theo từng socket, atomic Lua, global due/sweeper, nhiều tab qua nhiều process; SIGKILL hết lease không để online treo. LastSeen ghi theo transition, không ghi DB mỗi heartbeat. Timing mặc định45s/10s/5s; backlog xử lý200 user/lượt nên không hứa offline50s ở mọi tải.
- Metadata Upload, quyền trước ghi và lúc tải, server-side canonical attachment, bind theo khóa message; bỏ public static; JWT/Blob preview, tải theo click, file legacy có kiểm tra message reference. Signature8KB,20 MiB/file,5 file/tin; không coi là antivirus. Cleanup dry-run/grace/claim/ref-check, giữ legacy không rõ nguồn; index fileId/url hỗ trợ truy vấn.
- Retry song song A/B giữ một message, không ghi đè timestamp/status; conflict409; preview tie-break messageId. Client account-bound atomic storage commit, bỏ response cũ, gộp refresh; cùng account refresh giữ history/draft. Bounded inactive history/drafts/recent IDs; giữ draft qua đổi hội thoại, xử lý duplicate unread; mobile có điều hướng.
- Compose mặc định2 backend qua Nginx 1.28 DNS resolve/least_conn, WebSocket-only hai phía, no polling fallback; shared volumes và non-root node. Docker up sinh secret thiếu an toàn, không đè secret; một backend để so sánh; down giữ dữ liệu. HTTPS template và đầu mối TURN cho B.

## Module/file chính

| Nhóm | Thay đổi/lý do |
|---|---|
| config/redis.js, cache/profile/presence/rate-limit services | Trạng thái dùng chung, startup/readiness, TTL/invalidation/lease/quota |
| access.service.js, upload.service.js, Upload model, controllers/middleware upload, cleanup script | Quyền dùng chung, metadata thật, download/legacy và dọn có chứng cứ |
| message.service.js, Message/Conversation models | Idempotent insert, không lùi seen/preview, fileId và index additive |
| app.js/index.js/socket.js, auth/friend/message controllers | Nối Redis, rate, cache/presence, global logout, lifecycle và HTTP/socket contract |
| App/ChatArea/Sidebar, api/session/socket, auth/chat stores, ProtectedAttachment | Multi-tab, retry, Blob preview, draft/memory và mobile |
| Compose/Nginx/Dockerfile/start-demo | Hai backend, DNS recreate, quyền source/volume, readiness, secret generation |
| integration/load/proxy/ui scripts + tests + docs | Kiểm chứng hành vi, số đo và contract ghép B |

Giữ nguyên từng byte Group.js, GroupMember.js, events.js và scaffold call signaling về chức năng (chỉ handler dùng safe/rate/auth chung). Không tự chọn schema Group/GroupMember/Conversation của B; Conversation chỉ thêm preview messageId, Message thêm fileId/index phụ.

## Đã chạy và kết quả

Môi trường Linux5 CPU/RAM ~33.29 GiB, host Node 24.22.1, container Node 22, Docker 29.9.2 rootless/Compose 2.40.3, Mongo 7/Redis 7/Nginx 1.28, Chromium headless.

| Kiểm tra | Kết quả / bằng chứng |
|---|---|
| Baseline ZIP nguyên gốc | 18 server +18 client đạt; syntax/build/lint đạt, reports/baseline-* |
| npm ci server/client và root lockfile | Đã chạy trên máy này; không chép node_modules giữa máy |
| npm run check:server |39 file JS được kiểm tra, reports/server-syntax.log |
| npm test |21 server +23 client =44 test đạt; gồm unit, HTTP loopback và stub/store/axios adapter; không gọi là toàn bộ E2E |
| client build / lint | Build production đạt; lint sạch, reports/client-build.log / client-lint.log |
| test:integration |10 nhóm ca hành vi đạt với2 process và Mongo/Redis thật; reports/integration.json/.log. Có Redis restart, client module thật nối lại sau503, cache stale-fill race, file quá20 MiB/legacy/cleanup, JWT expiry/logout |
| test:smoke |18 assertion + kiểm tra HTTP status đạt, reports/smoke.log; tài khoản smoke_* trên DB demo riêng |
| test:proxy hai backend | Socket4/4 phân phối thực, file tải qua A/B, outsider403; recreate B đổi172.19.0.5→172.19.0.8, proxy phục hồi và file còn nguyên; reports/proxy-two.json |
| test:proxy một backend |8 socket đều server-a; download/quyền đạt, reports/proxy-single.json |
| test:ui |8 luồng Chromium thật: desktop/mobile, gửi/retry, ảnh/Blob, offline→161 tin đủ dòng UI, cross-tab refresh/account/logout; không pageerror; reports/ui.json/.log |
| Docker config/build/up/down | Đã chạy, readiness toàn stack đạt; down/up1 rồi về2 backend giữ volume; reports/volume-persistence.json chứng minh metadata/file thử cũ còn tải được |
| Khởi động từ source sạch | Không có .env/node_modules, tự sinh hai secret khác nhau ≥32 ký tự, sáu service ready; reports/clean-start.json |
| Audit index | Chỉ đọc, không duplicate trong DB test; index cursor/unique/fileId/url hiện diện, reports/index-audit.log |
| Load smoke/đo ngắn |20/100/500/1000 kết nối,1/2 process; JSON/CSV và BENCHMARK_RESULTS.md. Một lượt lỗi cổng Docker trước workload được giữ riêng, đã sửa harness và retry thành công |

Ở1000 kết nối,20%senders×1 tin/s,128 bytes text, warmup3s/run15s: mỗi lượt1/2 backend gửi3000 tin, ACK 3000/3000,0 missing sau tải bù,0 DBduplicate. ACK p95 lần lượt25.08ms/20.61ms, peer p95 25.03ms/22.02ms. Đây là lượt ngắn cùng máy, không chứng nhận1000 user production; ở100/500 hai backend không nhanh hơn trong phép đo. Raw CPU/RAM/lag và nhận xét khác biệt xem BENCHMARK_RESULTS. Số đo được thu trong quá trình triển khai; các bổ sung cuối về subscription ACK, retry handshake và index file được kiểm tra lại bằng integration/build/UI, không biến các lượt ngắn thành benchmark dài.

Không tính nhóm/cuộc gọi/TURN là pass. Không tắt auth/permission/payload/rate để đo. Integration rút TTL và tăng RATE_MESSAGE riêng để thử>150 tin nhanh, đã ghi rõ trong TEST_PLAN; load dùng quota mặc định.

## Lỗi đã tìm và khắc phục trong quá trình chạy

- Sandbox mạng ban đầu không tới proxy; cài dependency bằng quyền thực thi phù hợp, giữ TLS/checksum verification. Baseline được chạy lại trên ZIP nguyên gốc sau cài xong.
- Source ZIP mang mode600/700 làm user node trong Docker không đọc được; chuẩn hóa quyền source và COPY --chown. Không chmod777 hoặc đổi user root để che lỗi.
- BusyBox healthcheck qua proxy trả403; wget loopback dùng `-Y off`. Không bỏ proxy cho Internet.
- Redis container restart với random host port đổi cổng làm harness không nối lại; dùng cổng loopback cố định do net.listen chọn. Một lượt load rootless bị va chạm dynamic port; đã sửa và giữ failure JSON.
- Adapter thư viện không await publish/subscribe promise; xử lý rejection, re-assert subscription ACK và readiness. Handshake503 ban đầu có thể bị coi nhầm auth error; tách status/code và test actual client retry.

## File/dependency xóa và đóng gói

Không xóa file nguồn/asset/dependency nào: rà imports, script, Docker COPY, HTML/favicon, docs và phân công không có ứng viên đủ căn cứ để xóa an toàn. Group/GroupMember/scaffold là phần B, không coi là rác. Nội dung tài liệu cũ được cập nhật tại chính file, không tạo final/final2 trùng nhau. Thêm dependencies runtime `ioredis`, `@socket.io/redis-adapter`; root devDependency `playwright`; lockfiles được package manager cập nhật.

Source ZIP bàn giao loại node_modules/dist/coverage/cache/logtạm/.env thật/.git/data/uploads thật và ZIP lồng; không xóa dữ liệu local. `reports/*.log` được chọn riêng là bằng chứng test đã rà, không log credentials/message bodies. Giữ favicon, .gitkeep, lockfiles, .env.example, Dockerfile và test. ZIP gốc và checkout Git vẫn nguyên.

## Ghép B và giới hạn

B đọc INTEGRATION_B: mở rộng access helper theo membership nhóm, thu hồi rooms/file quyền khi rời, thiết kế group message/read state/migration và callId/busy/timeout/ICE lifecycle, thêm UI và test2 thiết bị/khác mạng/TURN. Adapter không tự quản lý call busy hoặc quyền nhóm. HTTPS template chưa có domain/cert để nghiệm thu; TURN chưa triển khai vì thuộc module B.

Mongo/Redis/storage/Nginx còn đơn lẻ; không HA, chưa kiểm tra host failover/soak dài/WAN/mọi browser/malware scan. Active history do người dùng tải nhiều trang vẫn có thể lớn, chưa virtualized list. Pub/Sub không replay/outbox; ACK chỉ lưu bền, tải bù phục hồi history. Cache request đang chạy có thể trả snapshot trước update, TTL giới hạn race DB-write/invalidation khi Redis lỗi. Redis epoch/presence state hash cần quản lý dung lượng theo vòng đời tài khoản khi thêm xóa user. File legacy không đủ chứng cứ quyền bị chặn và được giữ, không xóa. Đồng hồ backend phải đồng bộ khi mở rộng khác host (JWT và lease dùng thời gian server); thử nghiệm hiện tại là các process/containers cùng host. Xem MIGRATION trước dùng DB cũ; không tự sync/drop index hoặc xóa dữ liệu trùng để nâng cấp.

Lệnh sử dụng chính: `npm run docker:up`, `npm run test:integration`, `npm run test:proxy`, `npm run test:ui`, `CLIENTS=100 BACKENDS=2 WARMUP=3 DURATION=15 npm run test:load`. README/TEST_PLAN có đầy đủ yêu cầu/môi trường/stack thử riêng. Toàn bộ source đã sửa nằm trong ZIP để người dùng review; nhóm/WebRTC vẫn chờ B.
