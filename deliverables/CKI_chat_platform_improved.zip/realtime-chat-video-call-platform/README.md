# Realtime Chat and Video Call Platform

Nền tảng React/Vite/Zustand và Node.js/Express/Socket.IO/Mongoose bằng JavaScript ESM, JSX. Bản bàn giao này triển khai phần A: nền tảng chat cá nhân, quyền file, Redis/scaling và công cụ kiểm chứng. Nhóm và WebRTC 1–1 vẫn do B triển khai; model/scaffold của B được giữ nguyên.

## Chạy demo bằng một lệnh

Cần Node.js ≥22.12, Docker daemon và Compose v2 hỗ trợ `--wait`:

```bash
npm run docker:up
```

Mở **http://localhost:3000**. Không cần cài npm ở host cho lệnh này. Script tạo `.env` nếu thiếu, chỉ thêm secret chưa tồn tại (hai giá trị ngẫu nhiên khác nhau), kiểm tra cấu hình và chờ readiness. Không in secret. Giá trị secret có sẵn nhưng rỗng/yếu phải được người vận hành sửa; không ghi đè tự động. Nếu dùng proxy có CA của cloud, script truyền CA bằng BuildKit secret khi `CODEX_PROXY_CERT` có sẵn; không tắt TLS verification.

Demo mặc định có **server-a và server-b**, MongoDB, Redis, frontend và Nginx. Chỉ Nginx mở cổng host. JWT secret, MongoDB, Redis và uploads dùng chung giữa hai backend. Named volumes `mongo-data`, `redis-data`, `uploads` được giữ khi dừng:

```bash
npm run docker:down
# So sánh một backend, sau khi dừng stack hai backend:
npm run docker:up:single
# Dừng trước khi đổi về hai backend:
npm run docker:down
npm run docker:up
```

Không dùng `down -v` cho dữ liệu thật. Volume uploads được khởi tạo với quyền user `node`; dữ liệu cũ có ownership khác cần sao lưu và sửa quyền theo UID của container trước khi chạy, không chmod 777. Nginx 1.28 dùng DNS resolver Docker và upstream `resolve`; có kiểm thử tạo lại backend đổi IP. Healthcheck của Compose không tự loại upstream: Nginx dùng lỗi kết nối/502/503 và `max_fails`/`fail_timeout`. POST đã chuyển tới backend không được tự retry qua Nginx; client retry bằng cùng clientMessageId.

Đổi cổng: đặt `APP_PORT=8080` và `CORS_ORIGIN=http://localhost:8080` trong `.env` trước khi chạy. Script tính CORS theo cổng khi chưa có cấu hình; giá trị có sẵn được giữ. `CORS_ORIGIN` nhận danh sách origin phân cách dấu phẩy. Không cần đổi transport: hai phía dùng **WebSocket-only**, không có long-polling fallback; do đó không cần sticky sessions. Mạng chặn WebSocket sẽ không có realtime, REST và tải bù vẫn dùng được khi backend sẵn sàng.

## Phát triển local

```bash
npm --prefix server ci
npm --prefix client ci
# Chuẩn bị MongoDB và Redis riêng cho development.
# Tạo server/.env theo server/.env.example; điền hai secret ngẫu nhiên khác nhau.
cd server
npm run dev
# Terminal khác, tại gốc:
npm --prefix client run dev
```

Backend local cổng 5000, Vite cổng 3000 proxy API, socket và file. `REDIS_URL` là bắt buộc cho workflow runtime, mặc định `redis://127.0.0.1:6379`; MongoDB mặc định local. Không có fallback presence/adapter thành Map trong production. Cache có thể đọc DB nếu Redis lỗi, nhưng readiness và các API mới fail-closed khi adapter/presence chưa sẵn sàng. Message đã ACK có trong MongoDB; realtime có thể bị mất trong khoảng outage nên client tải bù sau reconnect hoặc `server:sync_required`.

| Biến | Mặc định / ý nghĩa |
|---|---|
| MONGO_URI | URL MongoDB riêng cho môi trường |
| REDIS_URL / REDIS_PREFIX | `redis://127.0.0.1:6379` / `chat:`; dùng prefix riêng khi chia Redis |
| INSTANCE_ID | Nhãn log, HTTP `X-Instance-Id` và socket `server:info` |
| UPLOAD_DIR | `uploads` theo working directory; Compose `/app/uploads` |
| CACHE_TTL_SECONDS | 60; epoch invalidation bảo vệ fill đang chạy |
| PRESENCE_TTL_MS / HEARTBEAT_MS / SWEEP_MS | Tên đầy đủ: `PRESENCE_TTL_MS=45000`, `PRESENCE_HEARTBEAT_MS=10000`, `PRESENCE_SWEEP_MS=5000` |
| RATE_AUTH / RATE_UPLOAD | 30/IP/phút cho login/register/refresh; 20/user/phút upload |
| RATE_MESSAGE / RATE_TYPING / RATE_EVENT | 120/120/600 mỗi user/phút, dùng chung Redis |
| TRUST_PROXY_HOPS | 0 local, 1 sau Nginx nội bộ; không expose trực tiếp backend khi tin proxy |
| AUTO_INDEX | `false` nếu vận hành quản lý index riêng; không dùng syncIndexes |

## Kiểm tra

```bash
npm run check:server
npm test
npm run build:client
npm --prefix client run lint
# Docker cần hoạt động; tự tạo DB/Redis/namespace/uploads thử nghiệm, hai process riêng:
npm run test:integration
# Một demo stack riêng đã chạy qua Nginx:
npm run test:smoke
npm run test:proxy
# UI test tùy chọn:
npm ci
npx playwright install chromium
npm run test:ui
# Hoặc dùng Chromium sẵn có:
# CHROMIUM_PATH=/usr/bin/chromium npm run test:ui
```

`test:smoke`, `test:proxy`, `test:ui` tạo tài khoản có prefix riêng; chỉ chạy trên stack demo thử nghiệm, không production. Hướng dẫn stack cô lập và recreate trong [TEST_PLAN](docs/TEST_PLAN.md). Nhóm/WebRTC chưa nghiệm thu, không tính test mô phỏng thành E2E. Kết quả thật và giới hạn xem [REVIEW_NOTES](docs/REVIEW_NOTES.md), JSON/CSV trong `reports/`.

## Đo tải có thể tái lập

```bash
npm run test:load:smoke
CLIENTS=100 BACKENDS=1 WARMUP=3 DURATION=15 SEED=42 npm run test:load
CLIENTS=100 BACKENDS=2 WARMUP=3 DURATION=15 SEED=42 npm run test:load
# Chỉ tăng 500/1000 sau khi mức trước ổn định.
```

Harness tự tạo containers MongoDB/Redis, DB/prefix và uploads riêng; seed tài khoản/bạn bè/hội thoại hợp lệ, JWT thật và giữ nguyên kiểm tra quyền/rate/payload. Hai backend là hai **process** thật; test Nginx riêng chứng minh proxy phân phối. `BACKENDS` 1/2; `CLIENTS` số chẵn 2–1000; `SENDER_RATIO=0.2`, `RATE=1` tin/s/người gửi; `PAYLOAD_BYTES=128`; `ACK_TIMEOUT_MS=8000`. Load không tự tăng hạn mức demo. `test:integration` tăng RATE_MESSAGE lên 1000 chỉ để kiểm tra catch-up >150 tin nhanh; TTL presence/cache được rút ngắn cho kiểm thử, không dùng làm số đo demo.

ACK latency đo từ phát Socket.IO tới ACK, peer latency từ phát tới peer event trên cùng đồng hồ monotonic của máy tạo tải. Báo realtime và tải bù riêng, đối chiếu ID với DB. JSON/CSV ghi workload, run ID, môi trường, CPU/RAM backend/Redis/MongoDB/generator và scheduling lag. Chạy 15 giây là **đo ngắn**, không phải soak test hoặc chứng nhận chịu 1000 người dùng production. Hai backend không mặc nhiên nhanh gấp đôi. Script Linux dùng `/proc` và `getconf` để đo process; chạy trên Linux/WSL2.

## File và dữ liệu cũ

`POST /api/upload/:conversationId` trả metadata server với `fileId`; tin nhắn chỉ cần `{ fileId }`. Download `GET /api/files/:fileId` dùng Authorization, không JWT trong URL. Owner preview file chưa gửi; thành viên chỉ tải được sau khi message tham chiếu. 20 MB/file, 5 file/tin; kiểm tra chữ ký 8 KB đầu chỉ nhận diện sơ bộ, không quét malware (DOCX mới kiểm tra vỏ ZIP).

URL legacy `/uploads/:name` đã có message tham chiếu vẫn dùng được **với JWT và quyền hội thoại**. File legacy không chứng minh được quyền bị chặn, không tự xóa. Schema Upload không có TTL. Dọn metadata/file bỏ dở mặc định dry-run, grace 24 giờ, tối thiểu 1 giờ:

```bash
cd server
npm run uploads:cleanup
npm run uploads:cleanup -- --apply
npm run indexes:audit
```

Chỉ xóa file có metadata quản lý không được message tham chiếu, hoặc file `u-UUID.ext` do bản này tạo bị bỏ dở trước metadata. Unclassified legacy và symlink được giữ. Sao lưu DB/uploads trước nâng cấp; xem [MIGRATION](docs/MIGRATION.md). Không đổi schema nhóm của B.

## Tài liệu

- [API](docs/API_DOCUMENTATION.md), [kiến trúc](docs/ARCHITECTURE.md), [kế hoạch test](docs/TEST_PLAN.md).
- [phân công](docs/TEAM_PLAN.md), [hướng dẫn ghép B](docs/INTEGRATION_B.md), [HTTPS/TURN](docs/HTTPS_AND_TURN.md).
- [số đo tải](docs/BENCHMARK_RESULTS.md), [ghi chú kiểm chứng](docs/REVIEW_NOTES.md), [checkpoint](docs/PROGRESS.md), [prompt tiếp tục](docs/CODEX_VSCODE_PROMPT.md).

MongoDB/Redis/storage/Nginx hiện vẫn là các điểm đơn lẻ; không gọi đây là high availability toàn hệ thống. Không nhúng secret TURN dài hạn vào frontend.
